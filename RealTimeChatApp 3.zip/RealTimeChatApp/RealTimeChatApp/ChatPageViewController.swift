//
//  ChatPageViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import UIKit
import Firebase
import FirebaseStorage

class ChatPageViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
//    @IBOutlet weak var lbl_UsernameChatVc: UILabel!
    
    @IBOutlet weak var ChatPageLoginUserProfilePhoto: UIImageView!
    @IBOutlet weak var ChatPageLoginUsername: UILabel!
    @IBOutlet weak var ChatTableView: UITableView!
    var users: [User] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.ChatPageLoginUserProfilePhoto.layer.cornerRadius =  (self.ChatPageLoginUserProfilePhoto.frame.height)/2
        self.ChatPageLoginUserProfilePhoto.clipsToBounds = true
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            return
        }
        fetchSenderDetails(for: currentUserId) { (username, profilePhotoURL) in
            DispatchQueue.main.async {
                self.ChatPageLoginUsername.text = username
                if let profilePhotoURL = profilePhotoURL {
                    URLSession.shared.dataTask(with: URL(string: profilePhotoURL)!) { data, response, error in
                        guard let data = data, error == nil else { return }
                        DispatchQueue.main.async {
                            self.ChatPageLoginUserProfilePhoto.image = UIImage(data: data)
                          
                        }
                    }.resume()
                }
            }
        }
                fetchUsers { [weak self] (users) in
            self?.users = users
            self?.ChatTableView.reloadData()
        }
//
        let addButton = UIButton(type: .custom)
               addButton.setImage(UIImage(systemName: "plus"), for: .normal)
               addButton.backgroundColor = .green
//             addButton.layer.cornerRadius = addButton.frame.height / 2
//               addButton.clipsToBounds = true
        addButton.layer.cornerRadius = 24
        addButton.layer.masksToBounds = true
               addButton.translatesAutoresizingMaskIntoConstraints = false
               addButton.addTarget(self, action: #selector(addButtonTapped(_:)), for: .touchUpInside)
               view.addSubview(addButton)
               
               NSLayoutConstraint.activate([
                   addButton.widthAnchor.constraint(equalToConstant: 50),
                   addButton.heightAnchor.constraint(equalTo: addButton.widthAnchor),
                   addButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
                   addButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
               ])
    }
    @objc func addButtonTapped(_ sender: UIButton) {
           print("Add button tapped!")
        if let imageDetailVC = storyboard?.instantiateViewController(withIdentifier: "HomePgaeVC") as? HomePageViewController {
            navigationController?.pushViewController(imageDetailVC, animated: true)
        }
       }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        fetchUsers { [weak self] (users) in
                 self?.users = users
                 self?.ChatTableView.reloadData()
             }
    }
  
    func fetchSenderDetails(for userID: String, completion: @escaping (String, String?) -> Void) {
        Database.database().reference().child("users").child(userID).observeSingleEvent(of: .value) { snapshot in
            if let userData = snapshot.value as? [String: Any],
               let username = userData["username"] as? String,
               let profilePhotoURL = userData["profilePhotoURL"] as? String {
                // Set the username
                self.ChatPageLoginUsername.text = username
                
                // Fetch profile photo and set it
                URLSession.shared.dataTask(with: URL(string: profilePhotoURL)!) { data, response, error in
                    guard let data = data, error == nil else { return }
                    DispatchQueue.main.async {
                        self.ChatPageLoginUserProfilePhoto.image = UIImage(data: data)
                        // You may want to handle image resizing and corner radius here as well
                    }
                }.resume()
            } else {
                completion("", nil)
            }
        }
    }

//    func fetchUsers(completion: @escaping ([User]) -> Void) {
//        guard let currentUserId = Auth.auth().currentUser?.uid else {
//            completion([])
//            return
//        }
//
//        Database.database().reference().child("messages").observeSingleEvent(of: .value) { (snapshot) in
//            var userIdSet = Set<String>()
//
//            for case let child as DataSnapshot in snapshot.children {
//                if let messageData = child.value as? [String: Any],
//                   let sender = messageData["sender"] as? String,
//                   let receiver = messageData["receiver"] as? String {
//                    if sender == currentUserId || receiver == currentUserId {
//                        let userId = sender == currentUserId ? receiver : sender
//                        userIdSet.insert(userId)
//                    }
//                }
//            }
//
//            var users: [User] = []
//            let dispatchGroup = DispatchGroup()
//
//            for userId in userIdSet {
//                dispatchGroup.enter()
//                self.fetchUserDetails(for: userId) { user in
//                    if let user = user {
//                        users.append(user)
//                    }
//                    dispatchGroup.leave()
//                }
//            }
//
//            dispatchGroup.notify(queue: .main) {
//
//                completion(users)
//            }
//        }
//    }
    
    func fetchUsers(completion: @escaping ([User]) -> Void) {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            completion([])
            return
        }

        Database.database().reference().child("messages").observeSingleEvent(of: .value) { (snapshot) in
            var userIdsAndTimestamps = [String: TimeInterval]()

            for case let child as DataSnapshot in snapshot.children {
                if let messageData = child.value as? [String: Any],
                   let sender = messageData["sender"] as? String,
                   let receiver = messageData["receiver"] as? String,
                   let timestamp = messageData["timestamp"] as? TimeInterval {
                    if sender == currentUserId || receiver == currentUserId {
                        let userId = sender == currentUserId ? receiver : sender
                        if let existingTimestamp = userIdsAndTimestamps[userId] {
                            userIdsAndTimestamps[userId] = max(existingTimestamp, timestamp)
                        } else {
                            userIdsAndTimestamps[userId] = timestamp
                        }
                    }
                }
            }

            var users: [User] = []
            let dispatchGroup = DispatchGroup()

            for (userId, timestamp) in userIdsAndTimestamps {
                dispatchGroup.enter()
                self.fetchUserDetails(for: userId) { user in
                    if let user = user {
                        var updatedUser = user
                        updatedUser.lastMessageTimestamp = timestamp
                        users.append(updatedUser)
                    }
                    dispatchGroup.leave()
                }
            }

            dispatchGroup.notify(queue: .main) {
                users.sort { $0.lastMessageTimestamp ?? 0 > $1.lastMessageTimestamp ?? 0 } // Sort based on last message timestamp
                completion(users)
            }
        }
    }
    func fetchUserDetails(for userId: String, completion: @escaping (User?) -> Void) {
                Database.database().reference().child("users").child(userId).observeSingleEvent(of: .value) { (snapshot) in
                    if let userData = snapshot.value as? [String: Any],
                       let email = userData["email"] as? String,
                       let username = userData["username"] as? String,
                       let phone = userData["Phone"] as? String,
                       let profilePhotoURL = userData["profilePhotoURL"] as? String { // Fetch profile photo URL
                        let user = User(email: email, username: username, phone: phone, uid: userId, profilePhotoURL: profilePhotoURL)
                        completion(user)
                    } else {
                        completion(nil)
                    }
                }
            }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return users.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "ChatVCCell", for: indexPath) as? TaskTableViewCell
            let user = users[indexPath.row]
            cell?.ChatVCUsernameLabel.text = user.username
            if let profilePhotoURL = URL(string: user.profilePhotoURL) {
                        URLSession.shared.dataTask(with: profilePhotoURL) { (data, response, error) in
                            if let data = data, let profilePhoto = UIImage(data: data) {
                                DispatchQueue.main.async {
                                    cell?.ChatVCProfilePhoto.image = profilePhoto
                                    cell?.ChatVCProfilePhoto.layer.cornerRadius =  (cell?.ChatVCProfilePhoto.frame.height)!/2
                                    cell?.ChatVCProfilePhoto.clipsToBounds = true
                                }
                            }
                        }.resume()
                    }

            return cell!
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedUser = users[indexPath.row]
        let thirdViewController = storyboard?.instantiateViewController(withIdentifier: "UserChatPageVC") as! UserChatPageViewController
        thirdViewController.selectedUser = selectedUser
        navigationController?.pushViewController(thirdViewController, animated: true)
    }

}
  

