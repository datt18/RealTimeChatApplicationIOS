//
//  userFile.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import Foundation
struct User {
    let email: String
    let username: String
    let phone: String
    let uid: String
    var lastMessageTimestamp: TimeInterval?
    var profilePhotoURL: String 
}
func == (lhs: User, rhs: User) -> Bool {
    return lhs.uid == rhs.uid 
}
struct Message {
    let sender: String
    let receiver: String
    let text: String
    let imageURL: String
    let documentURL : String?
    let timestamp: TimeInterval
}

//struct Message {
//    let sender: String
//    let receiver: String
//    let text: String?
//    let timestamp: TimeInterval
//}
//struct PhotoMessage {
//    let sender: String
//    let receiver: String
//    let imageURL: String
//    let timestamp: TimeInterval
//}

