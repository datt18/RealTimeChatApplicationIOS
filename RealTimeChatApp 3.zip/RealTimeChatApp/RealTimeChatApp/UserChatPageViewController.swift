
//
//  UserChatPageViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 22/03/24.
//

import UIKit
import Firebase
import FirebaseStorage
import PDFKit
class UserChatPageViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate & UINavigationControllerDelegate, UIDocumentPickerDelegate {
    
    
    @IBOutlet weak var UserChatVCSendButton: UIButton!
    @IBOutlet weak var UserChatVCusernameLabel: UILabel!
    @IBOutlet weak var userMessageInputTextField: UITextField!
    @IBOutlet weak var UserChatPageUserProfileImageView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    let activityIndicator = UIActivityIndicatorView(style: .medium)

    var selectedUser: User?
//    var currentUserName: String?
    var messages: [Message] = []
    var combinedMessages: [Message] = []
    var sectionedMessages: [[Message]] = []

    var selectedUserId = ""
    var imagePicker = UIImagePickerController()
    enum MessageCellType {
        case senderText
        case receiverText
        case senderImage
        case receiverImage
       
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
//        tableView.backgroundView = UIImageView(image: UIImage(named: "whats.jpeg"))
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
        self.scrollToBottom()
//        fetchMessages()
        tableView.showsVerticalScrollIndicator = false

        imagePicker.delegate = self
        userMessageInputTextField.delegate = self
        UserChatVCusernameLabel.text = selectedUser?.username
        if let profilePhotoURL = selectedUser?.profilePhotoURL {
                        // Download and set the profile photo
                        if let url = URL(string: profilePhotoURL) {
                            URLSession.shared.dataTask(with: url) { data, response, error in
                                if let data = data {
                                    DispatchQueue.main.async {
                                        self.UserChatPageUserProfileImageView.image = UIImage(data: data)
                                    }
                                }
                            }.resume()
                        }
                    }

        selectedUserId = selectedUser?.uid ?? ""
        userMessageInputTextField.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        userMessageInputTextField.layer.borderColor = UIColor.black.cgColor
        userMessageInputTextField.layer.borderWidth = 1.5
        userMessageInputTextField.layer.cornerRadius = 15.0
        userMessageInputTextField.layer.borderColor = UIColor.lightGray.cgColor
      
        UserChatPageUserProfileImageView.layer.cornerRadius = UserChatPageUserProfileImageView.frame.height/2
        UserChatPageUserProfileImageView.layer.masksToBounds = true
        UserChatVCSendButton.layer.cornerRadius = UserChatVCSendButton.frame.height/2
        UserChatVCSendButton.layer.masksToBounds = true
        UserChatVCSendButton.isEnabled = false
     
        sectionedMessages = []
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        self.navigationController?.isNavigationBarHidden = false
        UserChatVCSendButton.isEnabled = false
        let SendPhotoButton = UIButton(type: .custom)
        SendPhotoButton.setImage(UIImage(systemName: "paperclip"), for: .normal)
        SendPhotoButton.tintColor = .systemBlue
        SendPhotoButton.addTarget(self, action: #selector(SendPhotoMessage), for: .touchUpInside)
        userMessageInputTextField.rightView = SendPhotoButton
        userMessageInputTextField.rightViewMode = .always
        fetchMessages()
        tableView.reloadData()
//        scrollToBottom()
//        tableView.showsVerticalScrollIndicator = false
    }
    
    func startLoading() {
            activityIndicator.startAnimating()
        }
        func stopLoading() {
            activityIndicator.stopAnimating()
        }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var newText = (textField.text ?? "") as NSString
        newText = newText.replacingCharacters(in: range, with: string) as NSString

        if newText.length == 0 {
            //  SearchtableView.reloadData()
            UserChatVCSendButton.isEnabled = false
            let SendPhotoButton = UIButton(type: .custom)
            SendPhotoButton.setImage(UIImage(systemName: "paperclip"), for: .normal)
            SendPhotoButton.tintColor = .systemBlue
            SendPhotoButton.addTarget(self, action: #selector(SendPhotoMessage), for: .touchUpInside)
            userMessageInputTextField.rightView = SendPhotoButton
            userMessageInputTextField.rightViewMode = .always


        } else {
                UserChatVCSendButton.isEnabled = true
//            }
////        else {
            //         SearchtableView.reloadData()
            let SendButton = UIButton(type: .custom)
            SendButton.setImage(UIImage(systemName: "message.fill"), for: .normal)
            SendButton.tintColor = .systemBlue
        //    SendButton.addTarget(self, action: #selector(SendTextMessage), for: .touchUpInside)
            userMessageInputTextField.rightView = SendButton
            userMessageInputTextField.rightViewMode = .always
        }
        return true
        
    }
    @objc func SendPhotoMessage() {
        showOptionsMenu()
    }
    func showOptionsMenu() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let sendPhotoAction = UIAlertAction(title: "Photo", style: .default) { _ in
            self.showPhotoOptionsMenu()
        }
        alertController.addAction(sendPhotoAction)
        
        let sendDocumentAction = UIAlertAction(title: "Document", style: .default) { _ in
            self.pickDocument()
        }
        alertController.addAction(sendDocumentAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    func showPhotoOptionsMenu() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let sendPhotoAction = UIAlertAction(title: "Photos", style: .default) { _ in
            self.onlyForPhoto()
        }
        alertController.addAction(sendPhotoAction)
        
        let sendDocumentAction = UIAlertAction(title: "Camara", style: .default) { _ in
            self.opencamara()
        }
        alertController.addAction(sendDocumentAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    func opencamara() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            // Show an alert indicating that the camera is not available
            let alert = UIAlertController(title: "Camera Not Available", message: "Sorry, camera is not available on this device.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    func pickDocument() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.item"], in: .import)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        documentPicker.modalPresentationStyle = .formSheet
        present(documentPicker, animated: true, completion: nil)
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedURL = urls.first else { return }
        
        let alertController = UIAlertController(title: "Selected Document", message: selectedURL.lastPathComponent, preferredStyle: .alert)
        
        let sendAction = UIAlertAction(title: "Send", style: .default) { _ in
            self.uploadDocument(url: selectedURL)
        }
        alertController.addAction(sendAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    func uploadDocument(url: URL) {
        print("doc ........")
        let storageRef = Storage.storage().reference().child("documents").child(UUID().uuidString)
        
        let uploadTask = storageRef.putFile(from: url, metadata: nil) { metadata, error in
            guard let metadata = metadata else {
                print("Error uploading document: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            storageRef.downloadURL { (downloadURL, error) in
                guard let downloadURL = downloadURL?.absoluteString else {
                    print("Error getting download URL: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                self.sendMessage(text: "", imageURL: "", documentURL: downloadURL)
            }
        }
        
        uploadTask.observe(.progress) { snapshot in
        }
        
        uploadTask.observe(.success) { snapshot in
        }
    }
    @objc func onlyForPhoto() {
        print("click photo button")
        let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                present(imagePicker, animated: true, completion: nil)

    }
    @IBAction func Btn_SendAction(_ sender: Any) {
        guard let messageText = userMessageInputTextField.text, !messageText.isEmpty else {
                return
            }
            sendMessage(text: messageText, imageURL: "")
        tableView.reloadData()
        scrollToBottom()
        let SendPhotoButton = UIButton(type: .custom)
        SendPhotoButton.setImage(UIImage(systemName: "paperclip"), for: .normal)
        SendPhotoButton.tintColor = .systemBlue
        SendPhotoButton.addTarget(self, action: #selector(SendPhotoMessage), for: .touchUpInside)
        userMessageInputTextField.rightView = SendPhotoButton
        userMessageInputTextField.rightViewMode = .always
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            picker.dismiss(animated: true) {
                let alert = UIAlertController(title: "Selected Photo", message: "\n\n\n\n\n\n", preferredStyle: .alert)

                let imageView = UIImageView(frame: CGRect(x: 95, y: 45, width: 80, height: 80))
                imageView.image = pickedImage
    
                imageView.contentMode = .scaleAspectFit
                alert.view.addSubview(imageView)
                
                let messageLabel = UILabel(frame: CGRect(x: 20, y: 125, width: 240, height: 40))
                           messageLabel.text = "You want to send this Photo?"
                           messageLabel.numberOfLines = 2
                           messageLabel.textAlignment = .center
                           alert.view.addSubview(messageLabel)

                let sendAction = UIAlertAction(title: "Send", style: .default) { _ in
                    self.uploadImageAndSendMessage(image: pickedImage)
                }
                alert.addAction(sendAction)
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    func uploadImageAndSendMessage(image: UIImage) {
           guard let imageData = image.jpegData(compressionQuality: 0.5) else {
               print("Failed to convert image to data")
               return
           }
           
           let imageName = UUID().uuidString
           let storageRef = Storage.storage().reference().child("images").child("\(imageName).jpg")
           
           storageRef.putData(imageData, metadata: nil) { (metadata, error) in
               if let error = error {
                   print("Error uploading image: \(error.localizedDescription)")
                   return
               }
               
               storageRef.downloadURL { (url, error) in
                   if let error = error {
                       print("Error getting download URL: \(error.localizedDescription)")
                       return
                   }
                   
                   if let downloadURL = url?.absoluteString {
                       // Send message with image URL
                       self.sendMessage(text: "", imageURL: downloadURL)
                   }
               }
           }
       }
    func sendMessage(text: String, imageURL: String, documentURL: String? = nil) {
        startLoading()
        guard let currentUserUID = Auth.auth().currentUser?.uid,
              let receiverUID = selectedUser?.uid else {
            return
        }

        let messageData: [String: Any] = [
            "sender": currentUserUID,
            "receiver": receiverUID,
            "text": text,
            "imageURL": imageURL,
            "documentURL": documentURL ?? "",
            "timestamp": ServerValue.timestamp()
        ]

        let messagesRef = Database.database().reference().child("messages")
        let newMessageRef = messagesRef.childByAutoId()

        newMessageRef.setValue(messageData) { error, _ in
            if let error = error {
                print("Error sending message: \(error.localizedDescription)")
            } else {
                print("Message sent successfully")
                self.userMessageInputTextField.text = ""
//                self.tableView.reloadData()
                self.fetchMessages()
                self.scrollToBottom()
                self.stopLoading()
            }
        }
    }

    func fetchMessages() {
        startLoading()
        guard let currentUserUID = Auth.auth().currentUser?.uid,
              let selectedUserId = selectedUser?.uid else {
            return
        }

        Database.database().reference().child("messages").observe(.value) { [self] snapshot in
            self.messages = []

            for case let child as DataSnapshot in snapshot.children {
                if let messageData = child.value as? [String: Any],
                   let sender = messageData["sender"] as? String,
                   let receiver = messageData["receiver"] as? String,
                   let text = messageData["text"] as? String,
                   let imageURL = messageData["imageURL"] as? String,
                   let documentURL = messageData["documentURL"] as? String, // Assuming you stored document URL
                   let timestamp = messageData["timestamp"] as? TimeInterval {

                    // Check if the message is between the current user and the selected user
                    if (sender == currentUserUID && receiver == selectedUserId) ||
                       (sender == selectedUserId && receiver == currentUserUID) {
                        let message = Message(sender: sender, receiver: receiver, text: text, imageURL: imageURL, documentURL: documentURL, timestamp: timestamp)
                        self.messages.append(message)
                    }
                }
            }
//            self.combinedMessages = self.messages.sorted(by: { $0.timestamp < $1.timestamp })
//          //  self.messages.sort(by: { $0.timestamp < $1.timestamp })
//            // Reload table view after fetching messages
//            self.tableView.reloadData()
//            self.scrollToBottom()
//            self.stopLoading()
            let groupedMessages = Dictionary(grouping: self.messages) { (message) -> Date in
                       let timestamp = message.timestamp
                       let date = Date(timeIntervalSince1970: TimeInterval(timestamp) / 1000) // Convert timestamp to Date
                       return Calendar.current.startOfDay(for: date) // Group by date (ignoring time)
                   }

                   let sortedKeys = groupedMessages.keys.sorted(by: { $0 > $1 })

            self.sectionedMessages = sortedKeys.map { groupedMessages[$0] ?? [] }
            sectionedMessages.reverse()
                   // Reload table view
                   tableView.reloadData()
            self.scrollToBottom()
                       self.stopLoading()
        }
    }

    func fetchSenderDetails(for userID: String, completion: @escaping (String, String?) -> Void) {
        Database.database().reference().child("users").child(userID).observeSingleEvent(of: .value) { snapshot in
            if let userData = snapshot.value as? [String: Any],
               let username = userData["username"] as? String,
               let profilePhotoURL = userData["profilePhotoURL"] as? String {
                completion(username, profilePhotoURL)
            } else {
                completion("", nil)
            }
        }
    }
  
    func numberOfSections(in tableView: UITableView) -> Int {
            return sectionedMessages.count
        }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return combinedMessages.count
        return sectionedMessages[section].count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let message = combinedMessages[indexPath.row]
        let message = sectionedMessages[indexPath.section][indexPath.row]

        switch getMessageCellType(for: message) {
        case .senderText:
            let cell = tableView.dequeueReusableCell(withIdentifier: "SenderMessageCell", for: indexPath) as! UserChatVCTableViewCell
            cell.UserChatVCmessageLabel.text = message.text
            cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)
            cell.UserChatVCmessageLabel.textAlignment = .left
            cell.UserChatVCmessageView.layer.maskedCorners = [.layerMaxXMaxYCorner,  .layerMinXMinYCorner]
            cell.UserChatVCmessageView.layer.cornerRadius = 10
            cell.UserChatVCmessageView.layer.masksToBounds = true
            let senderID = message.sender
                   fetchSenderDetails(for: senderID) { username, profilePhotoURL in
                       if let url = URL(string: profilePhotoURL ?? "") {
                           URLSession.shared.dataTask(with: url) { data, response, error in
                               if let data = data {
                                   DispatchQueue.main.async {
                                       cell.UserChatVCTableViewProfilePhoto.image = UIImage(data: data)
                                       cell.UserChatVCTableViewProfilePhoto.layer.cornerRadius =  (cell.UserChatVCTableViewProfilePhoto.frame.height)/2
                                       cell.UserChatVCTableViewProfilePhoto.clipsToBounds = true
                                   }
                               }
                           }.resume()
                       }
                   }

            return cell
        case .receiverText:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReceiverMessageCell", for: indexPath) as! UserChatVCTableViewCell
            cell.UserChatVCmessageLabel.text = message.text
            cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)
            cell.UserChatVCmessageView.layer.maskedCorners = [ .layerMaxXMinYCorner, .layerMinXMaxYCorner]
                          cell.UserChatVCmessageView.layer.cornerRadius = 10
                          cell.UserChatVCmessageView.layer.masksToBounds = true

            let senderID = message.sender
                   fetchSenderDetails(for: senderID) { username, profilePhotoURL in
                       if let url = URL(string: profilePhotoURL ?? "") {
                           URLSession.shared.dataTask(with: url) { data, response, error in
                               if let data = data {
                                   DispatchQueue.main.async {
                                       cell.UserChatVCTableViewProfilePhoto.image = UIImage(data: data)
                                       cell.UserChatVCTableViewProfilePhoto.layer.cornerRadius =  (cell.UserChatVCTableViewProfilePhoto.frame.height)/2
                                       cell.UserChatVCTableViewProfilePhoto.clipsToBounds = true
                                   }
                               }
                           }.resume()
                       }
                   }
            return cell
        case .senderImage:
            let cell = tableView.dequeueReusableCell(withIdentifier: "SenderPhotoCell", for: indexPath) as! UserChatVCTableViewCell
            cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)
            if let url = URL(string: message.imageURL) {
                            URLSession.shared.dataTask(with: url) { data, response, error in
                                if let data = data {
                                    DispatchQueue.main.async {
                                        cell.UserChatVCTableViewMessagePhoto.image = UIImage(data: data)
                                    }
                                }
                            }.resume()
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleImageTap(_:)))
                        cell.UserChatVCTableViewMessagePhoto.isUserInteractionEnabled = true
                        cell.UserChatVCTableViewMessagePhoto.addGestureRecognizer(tapGesture)
                        }
            else if let documentURL = message.documentURL, let documentData = try? Data(contentsOf: URL(string: documentURL)!) {
                cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)
                    let documentText = String(data: documentData, encoding: .utf8)
                    cell.UserChatVCTableViewMessagePhoto.image = UIImage(systemName: "doc.text")
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDocumentTap(_:)))
                cell.UserChatVCTableViewMessagePhoto.isUserInteractionEnabled = true
                cell.UserChatVCTableViewMessagePhoto.addGestureRecognizer(tapGesture)

                    
                } else {
            
                    cell.UserChatVCTableViewMessagePhoto.image = UIImage(systemName: "doc.text")
                    cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)

                }

            cell.UserChatVCTableViewMessagePhoto.layer.maskedCorners = [.layerMaxXMaxYCorner,  .layerMinXMinYCorner]
            cell.UserChatVCTableViewMessagePhoto.layer.cornerRadius = 10
            cell.UserChatVCTableViewMessagePhoto.layer.masksToBounds = true
            let senderID = message.sender
                   fetchSenderDetails(for: senderID) { username, profilePhotoURL in
                       if let url = URL(string: profilePhotoURL ?? "") {
                           URLSession.shared.dataTask(with: url) { data, response, error in
                               if let data = data {
                                   DispatchQueue.main.async {
                                       cell.UserChatVCTableViewProfilePhoto.image = UIImage(data: data)
                                       cell.UserChatVCTableViewProfilePhoto.layer.cornerRadius =  (cell.UserChatVCTableViewProfilePhoto.frame.height)/2
                                       cell.UserChatVCTableViewProfilePhoto.clipsToBounds = true
                                   }
                               }
                           }.resume()
                       }
                   }
            return cell
        case .receiverImage:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReceiverPhotoCell", for: indexPath) as! UserChatVCTableViewCell
            cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)
            if let url = URL(string: message.imageURL) {
                            URLSession.shared.dataTask(with: url) { data, response, error in
                                if let data = data {
                                    DispatchQueue.main.async {
                                        cell.UserChatVCTableViewMessagePhoto.image = UIImage(data: data)
                                    }
                                }
                            }.resume()
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleImageTap(_:)))
                        cell.UserChatVCTableViewMessagePhoto.isUserInteractionEnabled = true
                        cell.UserChatVCTableViewMessagePhoto.addGestureRecognizer(tapGesture)

                        }
            else if let documentURL = message.documentURL, let documentData = try? Data(contentsOf: URL(string: documentURL)!) {
                cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)

                    let documentText = String(data: documentData, encoding: .utf8)
                    cell.UserChatVCTableViewMessagePhoto.image = UIImage(systemName: "doc.text")
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDocumentTap(_:)))
                cell.UserChatVCTableViewMessagePhoto.isUserInteractionEnabled = true
                cell.UserChatVCTableViewMessagePhoto.addGestureRecognizer(tapGesture)
                } else {
                    cell.UserChatVCTableViewMessagePhoto.image = UIImage(systemName: "doc.text")
                    cell.UserChatVCMSGTimeLabel.text = formatTimestamp(message.timestamp)

                }
            cell.UserChatVCTableViewMessagePhoto.layer.maskedCorners = [ .layerMaxXMinYCorner, .layerMinXMaxYCorner]
                          cell.UserChatVCTableViewMessagePhoto.layer.cornerRadius = 10
                          cell.UserChatVCTableViewMessagePhoto.layer.masksToBounds = true
            let senderID = message.sender
                   fetchSenderDetails(for: senderID) { username, profilePhotoURL in
                       if let url = URL(string: profilePhotoURL ?? "") {
                           URLSession.shared.dataTask(with: url) { data, response, error in
                               if let data = data {
                                   DispatchQueue.main.async {
                                       cell.UserChatVCTableViewProfilePhoto.image = UIImage(data: data)
                                       cell.UserChatVCTableViewProfilePhoto.layer.cornerRadius =  (cell.UserChatVCTableViewProfilePhoto.frame.height)/2
                                       cell.UserChatVCTableViewProfilePhoto.clipsToBounds = true
                                   }
                               }
                           }.resume()
                       }
                   }
            return cell
            
        }
    }
  
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
           let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 30))
           headerView.backgroundColor = .white
           
           let label = UILabel(frame: CGRect(x: 0, y: 0, width: 105 , height: 25))
           label.font = UIFont.boldSystemFont(ofSize: 14)
           label.textColor = .white
           label.textAlignment = .center
           label.backgroundColor = .darkGray
           label.layer.cornerRadius = 10
           label.layer.masksToBounds = true
        let sectionDate = sectionedMessages[section][0].timestamp
        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "MMM d, yyyy"
        dateFormatter.timeZone = TimeZone.current
        let date = Date(timeIntervalSince1970: TimeInterval(sectionDate) / 1000)
        let calendar = Calendar.current
    //    label.text = dateFormatter.string(from: date)
        if calendar.isDateInToday(date) {
            label.text = "Today"
        } else if calendar.isDateInYesterday(date) {
            label.text = "Yesterday"
        }
        //        else if let weekday = calendar.dateComponents([.weekday], from: date).weekday {
        //            let weekdaySymbols = dateFormatter.shortWeekdaySymbols
        //            return (weekdaySymbols?[weekday - 1])!
        else if calendar.isDate(date, equalTo: Date(), toGranularity: .weekOfYear) {
            dateFormatter.dateFormat = "EEEE"
            label.text = dateFormatter.string(from: date)
        } else {
            dateFormatter.dateFormat = "yyyy-MMM-dd"
            label.text = dateFormatter.string(from: date)
        }
           label.frame.origin = CGPoint(x: 0, y: 0)
               label.center.x = headerView.bounds.midX
               
               headerView.addSubview(label)
               return headerView
       }

        func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 30
        }
    
    @objc private func handleImageTap(_ sender: UITapGestureRecognizer) {
        
        if let tappedImageView = sender.view as? UIImageView {
            let point = sender.location(in: tableView)
            if let indexPath = tableView.indexPathForRow(at: point) {
                let message = sectionedMessages[indexPath.section][indexPath.row]
                if let imageURL = URL(string: message.imageURL) {
                 
                    let photoViewController = PhotoViewController(imageURL: imageURL)
                    navigationController?.pushViewController(photoViewController, animated: true)
                }
            }
        }
    }
    func formatTimestamp(_ timestamp: TimeInterval) -> String {
        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "MMM d, h:mm a"
        dateFormatter.dateFormat = "h:mm a"
        dateFormatter.timeZone = TimeZone.current
        let date = Date(timeIntervalSince1970: timestamp / 1000)
        return dateFormatter.string(from: date)
    }

    @objc private func handleDocumentTap(_ sender: UITapGestureRecognizer) {
            if let tappedImageView = sender.view as? UIImageView {
                let point = sender.location(in: tableView)
                if let indexPath = tableView.indexPathForRow(at: point) {
                    let message = sectionedMessages[indexPath.section][indexPath.row]
                    
                    if let documentURL = URL(string: message.documentURL!) {
                        let pdfViewController = DocumentViewController(documentURL: documentURL)
                        navigationController?.pushViewController(pdfViewController, animated: true)
                        
                    }
                    else {
                        
                        if let documentURL = message.documentURL {
                            if let documentData = try? Data(contentsOf: URL(string: documentURL)!) {
                                let documentText = String(data: documentData, encoding: .utf8)
                                let documentViewController = DocumentViewController(documentText: documentText ?? "")
                                navigationController?.pushViewController(documentViewController, animated: true)
                            }
                        }
                    }
                }
            }
        }
    
        private func getMessageCellType(for message: Message) -> MessageCellType {
        let isSender = message.sender == Auth.auth().currentUser?.uid

        if !message.text.isEmpty {
            return isSender ? .senderText : .receiverText
        } else {
            return isSender ? .senderImage : .receiverImage
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return UITableView.automaticDimension
    }
    private func scrollToBottom() {
        DispatchQueue.main.async {
            let lastSection = self.tableView.numberOfSections
            if lastSection > 0 {
                let lastRowInSection = self.tableView.numberOfRows(inSection: lastSection - 1) - 1
                if lastRowInSection >= 0 {
                    let lastIndexPath = IndexPath(row: lastRowInSection, section: lastSection - 1)
                    self.tableView.scrollToRow(at: lastIndexPath, at: .bottom, animated: true)
                }
            }
        }
    }
}
    


