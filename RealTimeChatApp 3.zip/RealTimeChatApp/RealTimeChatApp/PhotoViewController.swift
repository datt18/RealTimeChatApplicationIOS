import UIKit

class PhotoViewController: UIViewController {
    let imageView = UIImageView()
    var imageURL: URL?

    init(imageURL: URL) {
        super.init(nibName: nil, bundle: nil)
        self.imageURL = imageURL
        setupImageView(with: imageURL)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
    }

    private func setupImageView(with imageURL: URL) {
        // Configure imageView
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        // Set imageView constraints
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])

        let downloadButton = UIButton(type: .system)
        downloadButton.setImage(UIImage(systemName: "square.and.arrow.down.fill"), for: .normal)
        downloadButton.tintColor = .systemBlue
        downloadButton.addTarget(self, action: #selector(downloadImage), for: .touchUpInside)
        view.addSubview(downloadButton)

        downloadButton.translatesAutoresizingMaskIntoConstraints = false
        downloadButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        downloadButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20).isActive = true

        // Load image from URL
        loadImage(from: imageURL)
    }

    private func loadImage(from url: URL) {
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let data = data, let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                self?.imageView.image = image
            }
        }.resume()
    }

    @objc func downloadImage() {
        guard let imageURL = imageURL else { return }

        let alertController = UIAlertController(title: "Download Image", message: "Do you want to download this image?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Yes", style: .default) { [weak self] _ in
            self?.startImageDownload(from: imageURL)
        })
        alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

    private func startImageDownload(from url: URL) {
        let session = URLSession(configuration: .default)
        let downloadTask = session.downloadTask(with: url) { [weak self] (location, response, error) in
            guard let location = location, error == nil else {
                print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            // Move downloaded file to documents directory
            do {
                let documentsDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                let destinationURL = documentsDirectory.appendingPathComponent(url.lastPathComponent)
                try FileManager.default.moveItem(at: location, to: destinationURL)
                print("Image downloaded successfully at: \(destinationURL)")
            } catch {
                print("Error saving image: \(error.localizedDescription)")
            }
        }
        downloadTask.resume()
    }
}
