//
//  RegistrationViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import UIKit
import Firebase
import FirebaseStorage

class RegistrationViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
     @IBOutlet weak var emailTextFieldRegistrationPage: UITextField!
     @IBOutlet weak var UserNameTextFieldRegistrationPage: UITextField!
     @IBOutlet weak var PhoneTextFieldRegistrationPage: UITextField!
     @IBOutlet weak var PasswordFieldRegistrationPage: UITextField!
     @IBOutlet weak var btn_registrationRegistrationPage: UIButton!
     @IBOutlet weak var lbl_LoginRegistrationPage: UILabel!
     @IBOutlet weak var btn_ProfilePhotoUploadRegVC: UIButton!
     @IBOutlet weak var Img_ProfilePhotoSelectedRegVC: UIImageView!

   
    override func viewDidLoad() {
        super.viewDidLoad()
       

        btn_registrationRegistrationPage.layer.cornerRadius = 10
        btn_registrationRegistrationPage.layer.masksToBounds = true
        
        let attributedString = NSMutableAttributedString(string: "have an Account? Log In!")
        let termsRange = (attributedString.string as NSString).range(of: "Log In!")
        attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 17), range: termsRange)
        lbl_LoginRegistrationPage.attributedText = attributedString
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped1))
        lbl_LoginRegistrationPage.isUserInteractionEnabled = true
        lbl_LoginRegistrationPage.addGestureRecognizer(tapGesture)
        
    }
    @objc func labelTapped1(sender: UITapGestureRecognizer) {
        print("click")
        let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "LoginVC") as! ViewController
        self.navigationController!.pushViewController(secondViewController, animated: true)
        
    }
    @IBAction func uploadPhotoButtonTapped(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            Img_ProfilePhotoSelectedRegVC.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func registerButtonTapped(_ sender: UIButton) {
            guard let email = emailTextFieldRegistrationPage.text, isValidEmail(email),
                  let password = PasswordFieldRegistrationPage.text, isValidPassword(password),
                  let username = UserNameTextFieldRegistrationPage.text, !username.isEmpty,
                  let mobileNumber = PhoneTextFieldRegistrationPage.text, isValidMobileNumber(mobileNumber) else {
                
                showAlert(message: "Please fill in all fields correctly.")
                return
            }

            // Convert image to Data
            guard let imageData = Img_ProfilePhotoSelectedRegVC.image?.jpegData(compressionQuality: 0.5) else {
                showAlert(message: "Please select a profile photo.")
                return
            }

            // Reference to Firebase Storage
            let storageRef = Storage.storage().reference().child("profile_photos").child("\(UUID().uuidString).jpg")

            // Upload image to Firebase Storage
            storageRef.putData(imageData, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("Error uploading image: \(error.localizedDescription)")
                    self.showAlert(message: "Image upload failed. Please try again.")
                } else {
                    // Image uploaded successfully, get download URL
                    storageRef.downloadURL { (url, error) in
                        guard let downloadURL = url?.absoluteString else {
                            print("Error getting download URL: \(error?.localizedDescription ?? "Unknown error")")
                            self.showAlert(message: "Image upload failed. Please try again.")
                            return
                        }

                        // User registration data including download URL
                        let userData = ["email": email, "username": username,"Phone":mobileNumber, "profilePhotoURL": downloadURL]

                        // Store user data in Realtime Database
                        Auth.auth().createUser(withEmail: email, password: password) { [weak self] authResult, error in
                            guard let self = self else { return }
                            if let error = error {
                                print("Error registering user: \(error.localizedDescription)")
                                self.showAlert(message: "Registration failed. Please try again.")
                            } else if let uid = authResult?.user.uid {
                                // User registered successfully, now store additional information in Firebase Realtime Database
                                let userReference = Database.database().reference().child("users").child(uid)
                                userReference.setValue(userData) { (error, ref) in
                                    if let error = error {
                                        print("Error storing user data: \(error.localizedDescription)")
                                        self.showAlert(message: "Registration failed. Please try again.")
                                    } else {
                                        print("User data stored successfully")
                                        self.showAlert(message: "Registration successfully Done!.")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        

   

//    @IBAction func registerButtonTapped(_ sender: UIButton) {
//        guard let email = emailTextFieldRegistrationPage.text, isValidEmail(email),
//              let password = PasswordFieldRegistrationPage.text, isValidPassword(password),
//              let username = UserNameTextFieldRegistrationPage.text, !username.isEmpty,
//              let mobileNumber = PhoneTextFieldRegistrationPage.text, isValidMobileNumber(mobileNumber) else {
//
//            showAlert(message: "Please fill in all fields correctly.")
//            return
//        }
//
//        Auth.auth().createUser(withEmail: email, password: password) { [weak self] authResult, error in
//            guard let self = self else { return }
//
//            if let error = error {
//                print("Error registering user: \(error.localizedDescription)")
//                showAlert(message: "Registration failed. Please try again.")
//            } else if let uid = authResult?.user.uid {
//                // User registered successfully, now store additional information in Firebase Realtime Database
//                let userReference = Database.database().reference().child("users").child(uid)
//                let userData = ["email": email, "username": username,"Phone":mobileNumber, "regUserId": uid]
//
//
//                userReference.setValue(userData) { (error, ref) in
//                    if let error = error {
//                        print("Error storing user data: \(error.localizedDescription)")
//                        //                        self.showAlert(message: "Registration failed. Please try again.")
//                    } else {
//                        print("User data stored successfully")
//                    showAlert(message: "Registration successfully Done!.")
//
//                    }
//                }
//            }
//        }

        func isValidEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
        }
        
        
        func isValidMobileNumber(_ mobileNumber: String) -> Bool {
            let mobileRegex = "^[0-9]{10}$"
            return NSPredicate(format: "SELF MATCHES %@", mobileRegex).evaluate(with: mobileNumber)
        }
        
        func isValidPassword(_ password: String) -> Bool {
            let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
            return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: password)
        }
        
        func showAlert(message: String) {
            let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
        
    }

