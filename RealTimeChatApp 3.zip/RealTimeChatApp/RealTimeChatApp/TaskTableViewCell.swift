//
//  TaskTableViewCell.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    @IBOutlet weak var Lbl_homepageTableUsername: UILabel!
    @IBOutlet weak var Img_HomepagetableProfilePhoto: UIImageView!
    
//    @IBOutlet weak var UserChatVCmessageLabel: UILabel!
//    @IBOutlet weak var UserChatVCUsernameLabel: UILabel!

    @IBOutlet weak var ChatVCProfilePhoto: UIImageView!
    @IBOutlet weak var ChatVCUsernameLabel: UILabel!

  
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
        
    }

}
