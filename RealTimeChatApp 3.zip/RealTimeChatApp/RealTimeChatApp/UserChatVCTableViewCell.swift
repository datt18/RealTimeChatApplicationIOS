//
//  UserChatVCTableViewCell.swift
//  RealTimeChatApp
//
//  Created by elsner on 26/03/24.
//

import UIKit

class UserChatVCTableViewCell: UITableViewCell {
    @IBOutlet weak var UserChatVCmessageLabel: UILabel!
    @IBOutlet weak var UserChatVCUsernameLabel: UILabel!
    @IBOutlet weak var UserChatVCMSGTimeLabel: UILabel!
    
    @IBOutlet weak var UserChatVCmessageView: UIView!
    @IBOutlet weak var UserChatVCTableViewProfilePhoto: UIImageView!
    @IBOutlet weak var UserChatVCTableViewMessagePhoto: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
