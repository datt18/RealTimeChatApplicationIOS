//
//  HomePageViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import UIKit
import FirebaseAuth
import Firebase

class HomePageViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var dropdownButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var users: [User] = []
    var lastSelectedUser: User?
    
    let dropdownMenu: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.isHidden = true
        stackView.backgroundColor = .white
        return stackView
    }()
    
    let blurEffectView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.alpha = 0.4
        return blurEffectView
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        view.addSubview(dropdownButton)
        view.addSubview(blurEffectView)
        blurEffectView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.8)
        blurEffectView.isHidden = true
        view.addSubview(dropdownMenu)
        setupConstraints()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGestureRecognizer)
        fetchUsers { [weak self] (users) in
            self?.users = users
            self?.tableView.reloadData()
        }
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        dropdownMenu.isHidden = true
        blurEffectView.isHidden = true
//        fetchUsers { [weak self] (users) in
//            self?.users = users
//            self?.tableView.reloadData()
//        }
//
//        tableView.reloadData()
//
    }
    func setupConstraints() {
        dropdownButton.translatesAutoresizingMaskIntoConstraints = false
        dropdownMenu.translatesAutoresizingMaskIntoConstraints = false
        blurEffectView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            dropdownButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            dropdownButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0),
            
            dropdownMenu.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 45),
            dropdownMenu.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -3),
            blurEffectView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurEffectView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            dropdownMenu.widthAnchor.constraint(equalToConstant: 120),
            dropdownMenu.heightAnchor.constraint(equalToConstant: 80),
            blurEffectView.topAnchor.constraint(equalTo: view.topAnchor),
            blurEffectView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
        ])
    }
    @IBAction func dropdownButtonTapped(_ sender: Any) {
        print("click btn")
        //        dropdownMenu.isHidden.toggle()
        //        updateDropdownMenu()
        //        blurEffectView.isHidden = !dropdownMenu.isHidden
        UIView.animate(withDuration: 0.3) {
            self.blurEffectView.isHidden = !self.dropdownMenu.isHidden
            self.dropdownMenu.isHidden.toggle()
            self.updateDropdownMenu()
        }
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        
        if !dropdownMenu.isHidden {
            UIView.animate(withDuration: 0.3) {
                self.dropdownMenu.isHidden = true
                self.blurEffectView.isHidden = true
            }
        }
        //        else {
        
        //          }
        
    }
    func updateDropdownMenu() {
        dropdownMenu.removeAllArrangedSubviews()
        let editButton = UIButton()
        editButton.setTitle("Search", for: .normal)
        editButton.setTitleColor(.black, for: .normal)
        editButton.addTarget(self, action: #selector(editButtonTapped), for: .touchUpInside)
        let logoutButton = UIButton()
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.setTitleColor(.black, for: .normal)
        logoutButton.addTarget(self, action: #selector(logoutButtonTapped), for: .touchUpInside)
        
        //        logoutButton.setContentHuggingPriority(.required, for: .horizontal)
        //        logoutButton.setContentCompressionResistancePriority(.required, for: .horizontal)
        
        dropdownMenu.addArrangedSubview(editButton)
        dropdownMenu.addArrangedSubview(logoutButton)
    }
    @objc func editButtonTapped() {
        
        print("Search")
    }
    @objc func logoutButtonTapped() {
        let confirmLogoutAlert = UIAlertController(title: "Confirm Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
        
        let cancelConfirmationAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        confirmLogoutAlert.addAction(cancelConfirmationAction)
        
        let confirmAction = UIAlertAction(title: "Yes", style: .default) { _ in
            do {
                try Auth.auth().signOut()
                if let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as? ViewController {
                    self.navigationController?.pushViewController(loginViewController, animated: true)
                }
                
            } catch let signOutError as NSError {
                print("Error signing out: \(signOutError.localizedDescription)")
            }
        }
        confirmLogoutAlert.addAction(confirmAction)
        self.present(confirmLogoutAlert, animated: true, completion: nil)
        print("Logout button tapped")
    }
    func fetchUsers(completion: @escaping ([User]) -> Void) {
        Database.database().reference().child("users").observeSingleEvent(of: .value) { (snapshot) in
            guard let usersDict = snapshot.value as? [String: [String: Any]] else {
                completion([])
                return
            }

            var users: [User] = []
            let currentUserId = Auth.auth().currentUser?.uid

            for (uid, userData) in usersDict {
                guard let email = userData["email"] as? String,
                      let username = userData["username"] as? String,
                      let phone = userData["Phone"] as? String,
                      uid != currentUserId else {
                    continue // current login user .... not show...
                }
                
                var profilePhotoURL = ""
                if let profilePhotoString = userData["profilePhotoURL"] as? String {
                    profilePhotoURL = profilePhotoString
                }

                let user = User(email: email, username: username, phone: phone, uid: uid, profilePhotoURL: profilePhotoURL)
                users.append(user)
            }
            users.sort { $0.username < $1.username }

            completion(users)
        }
    }

//    func fetchUsers(completion: @escaping ([User]) -> Void) {
//        Database.database().reference().child("users").observeSingleEvent(of: .value) { (snapshot) in
//            guard let usersDict = snapshot.value as? [String: [String: Any]] else {
//                completion([])
//                return
//            }
//
//            var users: [User] = []
//            let currentUserId = Auth.auth().currentUser?.uid
//
//            for (uid, userData) in usersDict {
//                guard let email = userData["email"] as? String,
//                      let username = userData["username"] as? String,
//                      let phone = userData["Phone"] as? String,
//                      uid != currentUserId else {
//                    continue // current login user .... not show...
//                }
//
//                let user = User(email: email, username: username, phone: phone, uid: uid)
//                users.append(user)
//            }
//            users.sort { $0.username < $1.username }
//
//            completion(users)
//        }
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomePgaeCell", for: indexPath) as? TaskTableViewCell
        cell?.backgroundColor = UIColor.white
        cell?.layer.borderColor = UIColor.lightGray.cgColor
        cell?.layer.borderWidth = 0.4
        let user = users[indexPath.row]
        cell?.Lbl_homepageTableUsername.text = user.username
        if let profilePhotoURL = URL(string: user.profilePhotoURL) {
             URLSession.shared.dataTask(with: profilePhotoURL) { (data, _, error) in
                 if let data = data, let profilePhoto = UIImage(data: data) {
                     DispatchQueue.main.async {
                         cell?.Img_HomepagetableProfilePhoto.image = profilePhoto
                         cell?.Img_HomepagetableProfilePhoto.layer.cornerRadius =  (cell?.Img_HomepagetableProfilePhoto.frame.height)!/2
                         cell?.Img_HomepagetableProfilePhoto.clipsToBounds = true
                     }
                 } else {
                     print("Error downloading profile photo: \(error?.localizedDescription ?? "")")
                 }
             }.resume()
         }
        
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedUser = users[indexPath.row]
      
        let thirdViewController = storyboard?.instantiateViewController(withIdentifier: "UserChatPageVC") as! UserChatPageViewController
        thirdViewController.selectedUser = selectedUser
        
        navigationController?.pushViewController(thirdViewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
        
    }
    
    
}
extension UIStackView {
    func removeAllArrangedSubviews() {
        arrangedSubviews.forEach { $0.removeFromSuperview() }
    }
}
