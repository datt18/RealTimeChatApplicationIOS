//
//  AfterChatVCViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 26/03/24.
//

import UIKit

class AfterChatVCViewController: UIViewController {
    @IBOutlet weak var AfterChatVCSendButton: UIButton!
    @IBOutlet weak var AfterChatVCusernameLabel: UILabel!
    @IBOutlet weak var AfterMessageInputTextField: UITextField!
    @IBOutlet weak var AfterChatPageUserProfileImageView: UIImageView!
    @IBOutlet weak var AfterTableView: UITableView!
    var selectedUser: User?

    var messages: [Message] = []
    var selectedUserId = ""

    override func viewDidLoad() {
        super.viewDidLoad()
//        AfterMessageInputTextField.delegate = self
//        AfterChatVCusernameLabel.text = selectedUser?.username
//        AfterMessageInputTextField.delegate = self
//        AfterTableView.dataSource = self
//        AfterTableView.delegate = self
        AfterMessageInputTextField.layer.borderColor = UIColor.black.cgColor
        AfterMessageInputTextField.layer.borderWidth = 1.5
        AfterMessageInputTextField.layer.cornerRadius = 15.0
        AfterMessageInputTextField.layer.borderColor = UIColor.lightGray.cgColor
      
        AfterChatPageUserProfileImageView.layer.cornerRadius = AfterChatPageUserProfileImageView.frame.height/2
        AfterChatPageUserProfileImageView.layer.masksToBounds = true
        AfterChatVCSendButton.layer.cornerRadius = AfterChatVCSendButton.frame.height/2
        AfterChatVCSendButton.layer.masksToBounds = true
        AfterChatVCSendButton.isEnabled = false
       
    }
    

}
