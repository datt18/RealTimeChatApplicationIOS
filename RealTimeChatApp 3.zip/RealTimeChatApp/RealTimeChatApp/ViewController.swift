//
//  ViewController.swift
//  RealTimeChatApp
//
//  Created by elsner on 21/03/24.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    @IBOutlet weak var emailTextFieldLoginPage: UITextField!
    @IBOutlet weak var passwordTextFieldLoginPage: UITextField!
    @IBOutlet weak var lbl_SignUpLoginpage: UILabel!
    @IBOutlet weak var btn_loginLoginPage: UIButton!
    var window: UIWindow?

    override func viewDidLoad() {
        super.viewDidLoad()
       
        Auth.auth().addStateDidChangeListener { [weak self] (auth, user) in
            if user != nil {
                let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let mainViewController = mainStoryboard.instantiateViewController(withIdentifier: "ChatPageVC") as! ChatPageViewController
                self?.navigationController?.pushViewController(mainViewController, animated: true)


            }
        }
        btn_loginLoginPage.layer.cornerRadius = 10
        btn_loginLoginPage.layer.masksToBounds = true
        
        let attributedString = NSMutableAttributedString(string: "Dont't have an Account? Sign Up!")
        let termsRange = (attributedString.string as NSString).range(of: "Sign Up!")
        attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 17), range: termsRange)
        lbl_SignUpLoginpage.attributedText = attributedString
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped))
        lbl_SignUpLoginpage.isUserInteractionEnabled = true
        lbl_SignUpLoginpage.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true

    }
    @objc func labelTapped(sender: UITapGestureRecognizer) {
        print("click")
        let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "RegVC") as! RegistrationViewController
        self.navigationController!.pushViewController(secondViewController, animated: true)
        
    }
  
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let email = emailTextFieldLoginPage.text, let password = passwordTextFieldLoginPage.text else { return }

        Auth.auth().signIn(withEmail: email, password: password) { [self] authResult, error in
            if let error = error {
                print("Error logging in: \(error.localizedDescription)")
                showAlert1(message: " login credentials not found ")

            }
            else {

                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "ChatPageVC") as! ChatPageViewController
                 navigationController?.pushViewController(vc, animated: true)
                    }
        }

    }
//
    func showAlert1(message: String) {
            let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
}

