import UIKit
import PDFKit

class DocumentViewController: UIViewController {
    var documentURL: URL?
    var documentText: String?

       init(documentURL: URL) {
           self.documentURL = documentURL
           super.init(nibName: nil, bundle: nil)
       }
    init(documentText: String) {
            self.documentText = documentText
            super.init(nibName: nil, bundle: nil)
        }

       required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
       
       override func viewDidLoad() {
           super.viewDidLoad()

           let pdfView = PDFView(frame: view.bounds)
           pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
           pdfView.displayMode = .singlePageContinuous
           view.addSubview(pdfView)
           
           if let document = PDFDocument(url: documentURL!) {
               pdfView.document = document
           } else {
               displayText(from: documentURL!)
                              if let documentText = documentText {
                          displayTextFromString(documentText)
                      }
               else{
                   displayText(from: documentURL!)
               }
           }
           
           let downloadButton = UIButton(type: .system)
           downloadButton.setImage(UIImage(systemName: "square.and.arrow.down.fill"), for: .normal)
           downloadButton.tintColor = .systemBlue
           downloadButton.addTarget(self, action: #selector(downloadDocument), for: .touchUpInside)
           view.addSubview(downloadButton)

           downloadButton.translatesAutoresizingMaskIntoConstraints = false
           downloadButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
           downloadButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20).isActive = true

       }
    func displayText(from url: URL) {
           do {
               let text = try String(contentsOf: url, encoding: .utf8)
               displayTextFromString(text)
           } catch {
               print("Error reading text from file: \(error.localizedDescription)")
           }
       }
       
//    func displayTextFromString(_ text: String) {
//           let textView = UITextView(frame: view.bounds)
//           textView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
//           textView.text = text
//           textView.isEditable = false // Ensure text view is not editable
//           view.addSubview(textView)
//       }
    func displayTextFromString(_ text: String) {
        let textViewWidthRatio: CGFloat = 0.8
        let textViewHeightRatio: CGFloat = 0.8
        
        let textViewWidth = view.bounds.width * textViewWidthRatio
        let textViewHeight = view.bounds.height * textViewHeightRatio
        
        let x = (view.bounds.width - textViewWidth) / 2
        let y = (view.bounds.height - textViewHeight) / 2
        
        let textViewFrame = CGRect(x: x, y: y, width: textViewWidth, height: textViewHeight)
        let textView = UITextView(frame: textViewFrame)
        
        textView.text = text
        textView.isEditable = false
        view.addSubview(textView)
    }
    @objc func downloadDocument() {
            let alert = UIAlertController(title: "Download", message: "Do you want to download the document?", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
                // Perform download here
                self.performDownload()
            }))
            
            alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
            
            present(alert, animated: true, completion: nil)
        }
    func performDownload() {
        guard let documentURL = documentURL else {
            print("No document URL available for download.")
            return
        }

        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: documentURL) {
                let fileManager = FileManager.default
                let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
                let folderName = "MyDownloadedDocuments" 
                let folderURL = documentsDirectory?.appendingPathComponent(folderName)

                if !fileManager.fileExists(atPath: folderURL!.path) {
                    do {
                        try fileManager.createDirectory(at: folderURL!, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creating directory: \(error.localizedDescription)")
                    }
                }

                let fileURL = folderURL?.appendingPathComponent(documentURL.lastPathComponent)

                do {
                    try data.write(to: fileURL!)
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Download Successful", message: "The document has been downloaded successfully.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                } catch {
                    print("Error saving file: \(error.localizedDescription)")
                }
            } else {
                print("Failed to get data from URL: \(documentURL)")
            }
        }
    }

}

