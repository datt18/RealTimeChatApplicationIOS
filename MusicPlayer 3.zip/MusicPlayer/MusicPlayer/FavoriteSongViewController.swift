import UIKit
import SQLite

class FavoriteSongsViewController: UIViewController , UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var favoriteSongs: [favoriteSong] = []
    var db: Connection!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupDatabase()
        fetchFavoriteSongs()
    }
    
    func setupDatabase() {
        // Set up database connection
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        do {
            db = try Connection("\(path)/albums.sqlite3")
        } catch {
            print("Error connecting to database: \(error)")
        }
    }
    
    func fetchFavoriteSongs() {
        do {
            let favoritesTable = Table("favorites1")
            let songNameColumn = Expression<String>("songName")
            let songPhotoColumn = Expression<Data>("songPhoto")
            let albumNameColumn = Expression<String>("albumName")
            let durationColumn = Expression<Double>("duration")
            let singerNameColumn = Expression<String>("singerName")
            // Add other necessary columns
            
            let query = favoritesTable.select(songNameColumn, songPhotoColumn, albumNameColumn, durationColumn, singerNameColumn)
            for row in try db.prepare(query) {
                let song = favoriteSong(songName: row[songNameColumn],
                                description: "", // Add description if needed
                                songPhotoData: row[songPhotoColumn],
                                mp3Data: nil, // You may not need mp3 data here
                                duration: row[durationColumn],
                                albumName: row[albumNameColumn],
                                singerName: row[singerNameColumn],
                                albumid: 0) // Add album ID if needed
                
                favoriteSongs.append(song)
            }
            
            tableView.reloadData()
        } catch {
            print("Error fetching favorite songs: \(error)")
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoriteSongs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoriteSongListCell", for: indexPath) as! TaskTableViewCell
        
        let song = favoriteSongs[indexPath.row]
        cell.FavoriteSongVCsongNameLabel.text = song.songName
        cell.FavoriteSongVCsingerNameLabel.text = song.singerName
        cell.FavoriteSongVCdurationLabel.text = String(format: "%.2f", song.duration)
        if let songPhoto = UIImage(data: song.songPhotoData) {
            cell.FavoriteSongVCsongImageView.image = songPhoto
            cell.FavoriteSongVCsongImageView.layer.cornerRadius =  cell.FavoriteSongVCsongImageView.frame.height/2
            cell.FavoriteSongVCsongImageView.clipsToBounds = true
        }
        
        return cell
    }
}


  
    
