//
//  favoriteSongsViewController.swift
//  MusicPlayer
//
//  Created by elsner on 10/04/24.
//

import UIKit
import SQLite
import AVFoundation

class favoriteSongsViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{
    @IBOutlet weak var favoriteSongVCtableView: UITableView!
    
    var favoriteSongs: [favoriteSong] = []
    var db: Connection!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        setupDatabase()
        fetchFavoriteSongs()
    }
    func setupDatabase() {
        // Set up database connection
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        do {
            db = try Connection("\(path)/albums.sqlite3")
        } catch {
            print("Error connecting to database: \(error)")
        }
    }
    
    func fetchFavoriteSongs() {
        do {
            let favoritesTable = Table("favorites1")
            let songNameColumn = Expression<String>("songName")
            let songPhotoColumn = Expression<Data>("songPhoto")
            let albumNameColumn = Expression<String>("albumName")
            let durationColumn = Expression<Double>("duration")
            let singerNameColumn = Expression<String>("singerName")
            let songDataColumn = Expression<Data>("songData")

            // Add other necessary columns
            
            let query = favoritesTable.select(songNameColumn, songPhotoColumn, albumNameColumn, durationColumn, singerNameColumn,songDataColumn)
            for row in try db.prepare(query) {
                let song = favoriteSong(songName: row[songNameColumn],
                                        description: "",
                                        songPhotoData: row[songPhotoColumn],
                                        mp3Data: row[songDataColumn],
                                        duration: row[durationColumn],
                                        albumName: row[albumNameColumn],
                                        singerName: row[singerNameColumn],
                                        albumid: 0)
                
                favoriteSongs.append(song)
            }
            favoriteSongVCtableView.reloadData()
        } catch {
            print("Error fetching favorite songs: \(error)")
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoriteSongs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoriteSongListCell", for: indexPath) as! TaskTableViewCell
        
        let song = favoriteSongs[indexPath.row]
        cell.FavoriteSongVCsongNameLabel.text = song.songName
        cell.FavoriteSongVCsingerNameLabel.text = song.singerName
        cell.FavoriteSongVCdurationLabel.text = String(format: "%.2f", song.duration)
        if let songPhoto = UIImage(data: song.songPhotoData) {
            cell.FavoriteSongVCsongImageView.image = songPhoto
            cell.FavoriteSongVCsongImageView.layer.cornerRadius =  cell.FavoriteSongVCsongImageView.frame.height/2
            cell.FavoriteSongVCsongImageView.clipsToBounds = true
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var selectedSong = favoriteSongs[indexPath.row]
        
        if let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AfterFavoriteSongPlayVC") as? AfterFavoriteViewController {
            
            destinationVC.song = selectedSong
            destinationVC.favoriteSongsselectedIndex = indexPath.row
            present(destinationVC, animated: true)
        }
    }
}
