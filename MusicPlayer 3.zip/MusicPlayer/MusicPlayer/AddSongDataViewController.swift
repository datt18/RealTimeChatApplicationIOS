//
//  AddSongDataViewController.swift
//  MusicPlayer
//
//  Created by elsner on 04/04/24.
//

import UIKit
import SQLite

class AddSongDataViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var songNameTextField: UITextField!
    @IBOutlet weak var singerNameTextField: UITextField!
    @IBOutlet weak var albumNameTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var addSongBtn: UIButton!
    @IBOutlet weak var addAlbumButton: UIButton!

    var db: Connection!
    var selectedMP3URL: URL?
    var albumPickerView = UIPickerView()
//    var albumOptions: [(name: String, id: Int)] = []
    var albumOptions: [albumOption] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        addSongBtn.layer.cornerRadius = 10
        addSongBtn.layer.masksToBounds = true
        songImageView.layer.cornerRadius =  songImageView.frame.height/2
        songImageView.clipsToBounds = true
        
        setupDatabase()
        
        albumPickerView.dataSource = self
               albumPickerView.delegate = self
               albumNameTextField.inputView = albumPickerView
        let pickerView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 250))
               pickerView.backgroundColor = .white

               let cancelButton = UIButton(type: .system)
               cancelButton.setTitle("Cancel", for: .normal)
               cancelButton.frame = CGRect(x: 8, y: 4, width: 60, height: 30)
               cancelButton.addTarget(self, action: #selector(cancelPicker), for: .touchUpInside)
               pickerView.addSubview(cancelButton)

               let picker = UIPickerView(frame: CGRect(x: 0, y: 34, width: view.frame.size.width, height: 216))
               picker.dataSource = self
               picker.delegate = self
               pickerView.addSubview(picker)
               albumNameTextField.inputView = pickerView
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupDatabase()
    }
    func setupDatabase() {
//            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
//            do {
//                db = try Connection("\(path)/songs.sqlite3")
//                createSongsTable()
//                fetchAlbums()
//            } catch {
//                print("Error: \(error)")
//            }
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
                do {
                    db = try Connection("\(path)/albums.sqlite3") // Use a different database name
                    createSongsTable()
                    fetchAlbums()
                } catch {
                    print("Error: \(error)")
                }

        }
    @objc func cancelPicker() {
            albumNameTextField.resignFirstResponder()
        }
    @IBAction func addAlbumButtonTapped(_ sender: UIButton) {
        albumNameTextField.becomeFirstResponder()
    }
//    func createTables() {
//        createSongsTable()
//    }
    
    // Create songs table
    func createSongsTable() {
        let songs = Table("songs")
        let id = Expression<Int>("id")
        let songName = Expression<String>("songName")
        let description = Expression<String>("description")
        let songPhoto = Expression<Data>("songPhoto")
        let mp3File = Expression<Data>("mp3File")
        let singerName = Expression<String>("singerName")
        let albumName = Expression<String>("albumName")
        let albumId = Expression<Int>("albumId")
        do {
            try db.run(songs.create(ifNotExists: true) { table in
                table.column(id, primaryKey: .autoincrement)
                table.column(songName)
                table.column(description)
                table.column(songPhoto)
                table.column(mp3File)
                table.column(singerName)
                table.column(albumName)
                table.column(albumId, defaultValue: 0)
            })
        } catch {
            print("Error creating songs table: \(error)")
        }
    }
    func fetchAlbums() {
           let albums = Table("albums")
           let albumNameExp = Expression<String>("albumName")
           let albumIdExp = Expression<Int>("id")

           do {
               albumOptions.removeAll() // Clear existing options before fetching again
               for album in try db.prepare(albums.select(albumNameExp, albumIdExp)) {
                   let albumName = album[albumNameExp]
                   let albumId = album[albumIdExp]
                   let albumOption = albumOption(name: albumName, id: albumId)
                   albumOptions.append(albumOption)
               }
               albumPickerView.reloadAllComponents()
           } catch {
               print("Error fetching album names: \(error)")
           }
       }

    @IBAction func choosePhotoButtonTapped(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    // Handle the selected photo
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            songImageView.image = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Open the document picker to choose an MP3 file
    @IBAction func chooseMP3ButtonTapped(_ sender: UIButton) {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.audio"], in: .import)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        documentPicker.modalPresentationStyle = .formSheet
        present(documentPicker, animated: true, completion: nil)
    }

    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let songName = songNameTextField.text,
                     let singerName = singerNameTextField.text,
                     let albumText = albumNameTextField.text,
                     let description = descriptionTextField.text,
                     let songPhotoData = songImageView.image?.pngData(),
                     let mp3Data = try? Data(contentsOf: selectedMP3URL!),
                     let albumIndex = albumOptions.firstIndex(where: { $0.name == albumText }) else {
                   return
               }
               
               let songs = Table("songs")
               let songNameExp = Expression<String>("songName")
               let descriptionExp = Expression<String>("description")
               let songPhotoExp = Expression<Data>("songPhoto")
               let mp3FileExp = Expression<Data>("mp3File")
               let singerNameExp = Expression<String>("singerName")
               let albumNameExp = Expression<String>("albumName")
               let albumIdExp = Expression<Int>("albumId")
               
               let albumId = albumOptions[albumIndex].id
               
               let insert = songs.insert(songNameExp <- songName,
                                         descriptionExp <- description,
                                         songPhotoExp <- songPhotoData,
                                         mp3FileExp <- mp3Data,
                                         singerNameExp <- singerName,
                                         albumNameExp <- albumText,
                                         albumIdExp <- albumId)
               do {
                   try db.run(insert)
                   print("Song data inserted successfully")
                   self.navigationController?.popViewController(animated: true)
               } catch {
                   print("Error inserting song data: \(error)")
               }
           }
}
extension AddSongDataViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        selectedMP3URL = url
        songNameTextField.text = url.lastPathComponent
    }
}
extension AddSongDataViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return albumOptions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return albumOptions[row].name
    }
    
   
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            if row < albumOptions.count {
                let selectedAlbum = albumOptions[row]
                albumNameTextField.text = selectedAlbum.name
                albumNameTextField.resignFirstResponder()
            } else {
                albumNameTextField.text = "New"
            }
    }
}
