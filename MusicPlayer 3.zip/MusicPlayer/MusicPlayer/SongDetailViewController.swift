//
//  SongDetailViewController.swift
//  MusicPlayer
//
//  Created by elsner on 04/04/24.
//

import UIKit
import AVFoundation
import SQLite

class SongDetailViewController: UIViewController , UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var songNameLabel: UILabel!
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var remaingTimeLabel: UILabel!
    @IBOutlet weak var ComplteTimeLable: UILabel!
    @IBOutlet weak var albumname: UILabel!
    @IBOutlet weak var Singername: UILabel!
    @IBOutlet weak var SongDetalstableView: UITableView!
    @IBOutlet weak var songPlayView: UIView!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var ForwardButton: UIButton!
    @IBOutlet weak var BackwardButton: UIButton!
    @IBOutlet weak var progressSlider: UISlider!
    var album: Album?
    var songs: [Song] = []
    var db: Connection!
    var timers: [Timer] = []
    var isPlaying: Bool = false
    var audioPlayer: AVAudioPlayer?
    var currentSongIndex: Int = 0
    var currentlyPlayingIndex: Int?

    override func viewDidLoad() {
        super.viewDidLoad()
        //        setRandomBackgroundColor()
        if let album = album {
            albumname.text = album.name
            if let albumPhoto = UIImage(data: album.photoData) {
                songImageView.image = albumPhoto
            }
        }
        if let albumId = album?.id {
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            do {
                db = try Connection("\(path)/albums.sqlite3")
                songs = getSongsForAlbum(albumId)
                playSong(atIndex: currentSongIndex)
            } catch {
                print("Error: \(error)")
            }
        }
        
        SongDetalstableView.delegate = self
        SongDetalstableView.dataSource = self
        SongDetalstableView.reloadData()
        updateProgressSlider()
        updateCompleteTimeLabel()
        updateCompleteTimeLabel()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        print("open")
        startTimer()
       // setRandomBackgroundColor()
      

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        audioPlayer?.stop()
        updateProgressSlider()
        updateCompleteTimeLabel()
        updateCompleteTimeLabel()
        stopAllTimers()
        print("close")
    }
    func setRandomBackgroundColor() {
        let randomRed = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
        let randomGreen = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
        let randomBlue = CGFloat(arc4random_uniform(256)) / 255.0 // Limiting the range to make it darker
        let randomAlpha = CGFloat(arc4random_uniform(256)) / 255.0
        let randomColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: randomAlpha)
        view.backgroundColor = randomColor
        //        songPlayView.backgroundColor = randomColor
        //        SongDetalstableView.backgroundColor = randomColor
    }
    
    func updateProgressSlider() {
        if let player = audioPlayer {
            let progress = Float(player.currentTime / player.duration)
            progressSlider.value = progress
        }
    }
    func updateRemainingTimeLabel() {
        if let player = audioPlayer {
            let remainingTime = Int(player.duration - player.currentTime)
            let minutes = remainingTime / 60
            let seconds = remainingTime % 60
            remaingTimeLabel.text = String(format: "%02d:%02d", minutes, seconds)
        }
    }
    func updateCompleteTimeLabel() {
        if let player = audioPlayer {
            let completeTime = Int(player.currentTime)
            let minutes = completeTime / 60
            let seconds = completeTime % 60
            ComplteTimeLable.text = String(format: "%02d:%02d", minutes, seconds)
        }
    }
    func startTimer() {
        let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.updateRemainingTimeLabel()
            self.updateCompleteTimeLabel()
            self.updateProgressSlider()
        }
        timers.append(timer)
    }
    func stopAllTimers() {
        for timer in timers {
            timer.invalidate()
        }
        timers.removeAll()
    }
    
    
    func playSong(atIndex index: Int) {
        guard index < songs.count else {
            return
        }
        currentlyPlayingIndex = index

        let song = songs[index]
        if let mp3Data = song.mp3Data {
            do {
                audioPlayer = try AVAudioPlayer(data: mp3Data)
                audioPlayer?.play()
                songNameLabel.text = song.songName
                isPlaying = true
                Singername.text = song.singerName
                playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
                startTimer()
                
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
    }
    @IBAction func playButtonTapped(_ sender: UIButton) {
        if isPlaying {
                   audioPlayer?.pause()
                   isPlaying = false
                   playPauseButton.setImage(UIImage(named: "play.circle.fill"), for: .normal)
                   stopAllTimers()
               } else {
            if let player = audioPlayer {
                player.play()
                isPlaying = true
                playPauseButton.setImage(UIImage(named: "pause.circle.fill"), for: .normal)
                startTimer()
            } else {
                guard currentSongIndex < songs.count else {
                    return
                }
                let song = songs[currentSongIndex]
                if let mp3Data = song.mp3Data {
                               do {
                                   audioPlayer = try AVAudioPlayer(data: mp3Data)
                                   audioPlayer?.play()
                                   audioPlayer?.currentTime = TimeInterval(progressSlider.value) * (audioPlayer?.duration ?? 0)
                                   songNameLabel.text = song.songName
                                   isPlaying = true
                                   playPauseButton.setImage(UIImage(named: "play.circle.fill"), for: .normal)
                                   startTimer()
                               } catch {
                        print("Error playing audio: \(error.localizedDescription)")
                    }
                }
            }
        }
    }

    @IBAction func forwardButtonTapped(_ sender: UIButton) {
        currentSongIndex += 1
        if currentSongIndex >= songs.count {
            
            currentSongIndex = 0
        }
        playSong(atIndex: currentSongIndex)
    }
    
    @IBAction func backwardButtonTapped(_ sender: UIButton) {
        currentSongIndex -= 1
        if currentSongIndex < 0 {
            currentSongIndex = songs.count - 1
        }
        playSong(atIndex: currentSongIndex)
    }
    
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        if let player = audioPlayer {
            let newTime = Double(sender.value) * player.duration
            player.currentTime = newTime
        }
    }
    func getSongsForAlbum(_ albumId: Int) -> [Song] {
        var albumSongs: [Song] = []
        let songsTable = Table("songs")
        let id = Expression<Int>("id")
        let songName = Expression<String>("songName")
        let description = Expression<String>("description")
        let songPhoto = Expression<Data>("songPhoto")
        let mp3File = Expression<Data>("mp3File")
        let singerName = Expression<String>("singerName")
        let albumIdColumn = Expression<Int>("albumId")
        
        let filteredSongs = songsTable.filter(albumIdColumn == albumId)
        
        do {
            let fetchedSongs = try db.prepare(filteredSongs)
            for song in fetchedSongs {
                let newSong = Song(id: song[id],
                                   songName: song[songName],
                                   description: song[description],
                                   songPhotoData: song[songPhoto],
                                   mp3Data: song[mp3File],
                                   duration: 0,
                                   albumName: "",
                                   singerName: song[singerName],
                                   albumid: albumId)
                albumSongs.append(newSong)
            }
            fetchSongDurations()
            
        } catch {
            print("Error retrieving songs for album: \(error)")
        }
        
        return albumSongs
    }
    func fetchSongDurations() {
        for (index, song) in songs.enumerated() {
            if let mp3Data = song.mp3Data,
               let player = try? AVAudioPlayer(data: mp3Data) {
                let duration = player.duration / 60
                songs[index].duration = duration
            }
        }
        SongDetalstableView.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongDetailsVCSongListCell", for: indexPath) as! TaskTableViewCell
        let song = songs[indexPath.row]
        
        cell.SongDetailsVCsongNameLabel.text = song.songName
        cell.SongDetailsVCsingerNameLabel.text = song.singerName
        //    cell.SongDetailsVCdurationLabel.text = String(format: "%.2f", song.duration)
        if let currentlyPlayingIndex = currentlyPlayingIndex, indexPath.row == currentlyPlayingIndex {
                cell.SongDetailsVCPlayButton.setImage(UIImage(named: "pause.circle.fill"), for: .normal)
            } else {
                cell.SongDetailsVCPlayButton.setImage(UIImage(named: "play.circle.fill"), for: .normal)
            }
        
        cell.SongDetailsVCPlayButton.tag = indexPath.row
            cell.SongDetailsVCPlayButton.addTarget(self, action: #selector(playButtonClick(_:)), for: .touchUpInside)
        
        if let songPhoto = UIImage(data: song.songPhotoData) {
            cell.SongDetailsVCsongImageView.image = songPhoto
            cell.SongDetailsVCsongImageView.layer.cornerRadius = 10
            cell.SongDetailsVCsongImageView.layer.masksToBounds = true
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedSongIndex = indexPath.row
        playSong(atIndex: selectedSongIndex)
        updateUIWithSelectedSong()
    }
    
    @objc func playButtonClick(_ sender: UIButton) {
        let selectedIndex = sender.tag
        playSong(atIndex: selectedIndex)
    }

    func updateUIWithSelectedSong() {
        guard currentSongIndex < songs.count else {
            return
        }
        
        // Update only the UI elements that should remain constant
        let selectedSong = songs[currentSongIndex]
        if songNameLabel.text == nil || songNameLabel.text!.isEmpty {
            songNameLabel.text = selectedSong.songName
        }
        if Singername.text == nil || Singername.text!.isEmpty {
            Singername.text = selectedSong.singerName
        }
        
    }
}
