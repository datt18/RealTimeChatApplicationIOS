//
//  SongPlayViewController.swift
//  MusicPlayer
//
//  Created by elsner on 05/04/24.
//

import UIKit
import SQLite
import AVFoundation
class SongPlayViewController: UIViewController {
    
    @IBOutlet weak var songNameLabel: UILabel!
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var remaingTimeLabel: UILabel!
    @IBOutlet weak var ComplteTimeLable: UILabel!
    @IBOutlet weak var albumname: UILabel!
    @IBOutlet weak var Singername: UILabel!
    @IBOutlet weak var SongDescription: UILabel!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var ForwardButton: UIButton!
    @IBOutlet weak var BackwardButton: UIButton!
    @IBOutlet weak var SongPlayVCFavoriteButton: UIButton!
    @IBOutlet weak var progressSlider: UISlider!
    var song: Song?
    var audioPlayer: AVAudioPlayer?
    var timers: [Timer] = []
    var isPlaying: Bool = false
    var newselectedSong: Song?
    var db: Connection!
    var relatedSongs: [Song] = []
    var isFavorite: Bool = false
    var selectedIndex: Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setRandomBackgroundColor()
        setupDatabase()
        setupTableView()
        if let song = song {
            songNameLabel.text = song.songName
            albumname.text = song.albumName
            Singername.text = song.singerName
            SongDescription.text = song.description
            startTimer()
            if let songPhoto = UIImage(data: song.songPhotoData) {
                songImageView.image = songPhoto
                songImageView.layer.cornerRadius = 10
                songImageView.layer.masksToBounds = true
                
                songImageView.layer.shadowColor = UIColor.black.cgColor
                songImageView.layer.shadowOpacity = 0.5
                songImageView.layer.shadowOffset = CGSize(width: 100, height: 100)
                songImageView.layer.shadowRadius = 10
                
            }
            playSelectedSong(song)
            fetchRelatedSongs(albumId: song.albumid)
        }
        updateProgressSlider()
        updateCompleteTimeLabel()
        updateCompleteTimeLabel()
        checkFavoriteStatus()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        print("open")
        setRandomBackgroundColor()
        startTimer()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        audioPlayer?.stop()
        playPauseButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
        updateProgressSlider()
        updateCompleteTimeLabel()
        updateCompleteTimeLabel()
        stopAllTimers()
        print("close")
    }
    func setRandomBackgroundColor() {
               let randomRed = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
               let randomGreen = CGFloat(arc4random_uniform(256)) / 255.0 // Limiting the range to make it darker
               let randomBlue = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
               let randomAlpha = CGFloat(arc4random_uniform(256)) / 255.0
               let randomColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: randomAlpha)
               view.backgroundColor = randomColor
        }
    func checkFavoriteStatus() {
           if let song = song {
               // Check if the song exists in the favorites table
               do {
                   let favoritesTable = Table("favorites1")
                   let songNameColumn = Expression<String>("songName")
                   let result = try db.scalar(favoritesTable.filter(songNameColumn == song.songName).count)
                   if result > 0 {
                       // Song is favorite
                       isFavorite = true
                       // Change favorite button appearance
                       SongPlayVCFavoriteButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                   } else {
                       // Song is not favorite
                       isFavorite = false
                       // Change favorite button appearance
                       SongPlayVCFavoriteButton.setImage(UIImage(systemName: "heart"), for: .normal)
                   }
               } catch {
                   print("Error checking favorite status: \(error)")
               }
           }
       }
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        if let song = song {
                   if isFavorite {
                       // Remove song from favorites
                       removeSongFromFavorites(song)
                   } else {
                       // Add song to favorites
                       addSongToFavorites(song)
                   }
                   // Toggle favorite status
                   isFavorite = !isFavorite
                   // Update UI based on favorite status
                   if isFavorite {
                       SongPlayVCFavoriteButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                   } else {
                       SongPlayVCFavoriteButton.setImage(UIImage(systemName: "heart"), for: .normal)
                   }
               }
    }
    func addSongToFavorites(_ song: Song) {
        do {
            let favoritesTable = Table("favorites1")
            let songNameColumn = Expression<String>("songName")
            let songDataColumn = Expression<Data>("songData")
            let songPhotoColumn = Expression<Data>("songPhoto")
            let albumNameColumn = Expression<String>("albumName")
            let durationColumn = Expression<Double>("duration")
            let singerNameColumn = Expression<String>("singerName")
            let descriptionColumn = Expression<String>("description")
            
            try db.run(favoritesTable.insert(
                                             songNameColumn <- song.songName,
                                             songPhotoColumn <- song.songPhotoData,
                                             songDataColumn <- song.mp3Data ?? Data(),
                                             albumNameColumn <- song.albumName,
                                             durationColumn <- song.duration,
                                             singerNameColumn <- song.singerName,
                                             descriptionColumn <- song.description))
            presentCustomAlert(message: "Song added to favorites", width: 210, duration: 1.5)
            print("Song added to favorites")
        } catch {
            print("Error adding song to favorites: \(error)")
        }
    }

    func removeSongFromFavorites(_ song: Song) {
           do {
               let favoritesTable = Table("favorites1")
               let songNameColumn = Expression<String>("songName")
               try db.run(favoritesTable.filter(songNameColumn == song.songName).delete())
               
               presentCustomAlert(message: "Song removed from favorites", width: 280, duration: 1.5)
               print("Song removed from favorites")
               
           } catch {
               print("Error removing song from favorites: \(error)")
           }
       }
    func setupDatabase() {
           let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
           do {
               db = try Connection("\(path)/albums.sqlite3")
               let favoritesTable = Table("favorites1")
               let songNameColumn = Expression<String>("songName")
               let songDataColumn = Expression<Data>("songData")
               let songPhotoColumn = Expression<Data>("songPhoto")
               let albumNameColumn = Expression<String>("albumName")
               let durationColumn = Expression<Double>("duration")
               let singerNameColumn = Expression<String>("singerName")
               let descriptionColumn = Expression<String>("description")

               try db.run(favoritesTable.create(ifNotExists: true) { table in
                   table.column(songNameColumn, primaryKey: true)
                       table.column(songDataColumn)
                       table.column(songPhotoColumn)
                       table.column(albumNameColumn)
                       table.column(durationColumn)
                       table.column(singerNameColumn)
                       table.column(descriptionColumn)
                   // Add other necessary columns
               })
               print("Database connected")
           } catch {
               print("Error connecting to database: \(error)")
           }
       }
//   func setupDatabase() {
//        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
//        do {
//            db = try Connection("\(path)/albums.sqlite3")
//        } catch {
//            print("Error: \(error)")
//        }
//    }
    func setupTableView() {
        
    }
    func fetchRelatedSongs(albumId: Int) {
        let songsTable = Table("songs")
        let songName = Expression<String>("songName")
        let singerName = Expression<String>("singerName")
        let songPhoto = Expression<Data>("songPhoto")
        let mp3File = Expression<Data>("mp3File")
        let albumid = Expression<Int>("albumId")
        if let currentSongName = song?.songName {
            let filteredSongs = songsTable.filter(albumid == albumId && songName != currentSongName)
            
            do {
                relatedSongs = try db.prepare(filteredSongs).map { row in
                    return Song(id: 0,
                                songName: row[songName],
                                description: "",
                                songPhotoData: row[songPhoto],
                                mp3Data: row[mp3File],
                                duration: 0,
                                albumName: "",
                                singerName: row[singerName],
                                albumid: row[albumid])
                }
                fetchSongDurations()
                
            } catch {
                print("Error retrieving related songs: \(error)")
            }
        }
    }
    
    func fetchSongDurations() {
        for (index, song) in relatedSongs.enumerated() {
            if let mp3Data = song.mp3Data,
               let player = try? AVAudioPlayer(data: mp3Data) {
                let duration = player.duration / 60
                relatedSongs[index].duration = duration
            }
        }
    }
    func updateRemainingTimeLabel() {
        if let player = audioPlayer {
            let remainingTime = Int(player.duration - player.currentTime)
            let minutes = remainingTime / 60
            let seconds = remainingTime % 60
            remaingTimeLabel.text = String(format: "%02d:%02d", minutes, seconds)
        }
    }
    func updateCompleteTimeLabel() {
        if let player = audioPlayer {
            let completeTime = Int(player.currentTime)
            let minutes = completeTime / 60
            let seconds = completeTime % 60
            ComplteTimeLable.text = String(format: "%02d:%02d", minutes, seconds)
        }
    }
    
    func startTimer() {
        let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.updateRemainingTimeLabel()
            self.updateCompleteTimeLabel()
            self.updateProgressSlider()
        }
        timers.append(timer)
    }
    func stopAllTimers() {
        for timer in timers {
            timer.invalidate()
        }
        timers.removeAll()
    }
    
    func updateProgressSlider() {
        if let player = audioPlayer {
            let progress = Float(player.currentTime / player.duration)
            progressSlider.value = progress
        }
    }
//    func playSelectedSong(_ selectedSong: Song) {
//        guard let mp3Data = selectedSong.mp3Data else {
//            return
//        }
//
//        do {
//            audioPlayer = try AVAudioPlayer(data: mp3Data)
//            audioPlayer?.play()
//            isPlaying = true
//            playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
//            startTimer()
//
//        } catch {
//            print("Error playing audio: \(error)")
//        }
//    }
    func playSelectedSong(_ selectedSong: Song) {
        guard let mp3Data = selectedSong.mp3Data else {
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(data: mp3Data)
            audioPlayer?.play()
            isPlaying = true
            playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
            startTimer()
            
            songNameLabel.text = selectedSong.songName
            albumname.text = selectedSong.albumName
            Singername.text = selectedSong.singerName
            SongDescription.text = selectedSong.description
            if let songPhoto = UIImage(data: selectedSong.songPhotoData) {
                songImageView.image = songPhoto
            }
            
            song = selectedSong
        } catch {
            print("Error playing audio: \(error)")
        }
    }
    @IBAction func forwardButtonTapped(_ sender: UIButton) {
        if relatedSongs.isEmpty {
            return
        }
        let currentIndex = relatedSongs.firstIndex(where: { $0.songName == song?.songName }) ?? 0
        let nextIndex = (currentIndex + 1) % relatedSongs.count
        let nextSong = relatedSongs[nextIndex]
        playSelectedSong(nextSong)
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        if relatedSongs.isEmpty {
            return
        }
        let currentIndex = relatedSongs.firstIndex(where: { $0.songName == song?.songName }) ?? 0
        let previousIndex = (currentIndex - 1 + relatedSongs.count) % relatedSongs.count
        let previousSong = relatedSongs[previousIndex]
        playSelectedSong(previousSong)
    }

    @IBAction func sliderValueChanged(_ sender: UISlider) {
        if let player = audioPlayer {
            let newTime = Double(sender.value) * player.duration
            player.currentTime = newTime
        }
    }
    @IBAction func playButtonTapped(_ sender: UIButton) {
        if isPlaying {
            // If currently playing, pause the audio
            audioPlayer?.pause()
            isPlaying = false
            playPauseButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
            stopAllTimers()
        } else {
            if let audioPlayer = audioPlayer {
                audioPlayer.play()
            } else {
                guard let song = song, let mp3Data = song.mp3Data else {
                    return
                }
                do {
                    audioPlayer = try AVAudioPlayer(data: mp3Data)
                    audioPlayer?.play()
                } catch {
                    print("Error playing audio: \(error)")
                    return
                }
            }
            isPlaying = true
            playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
            startTimer()
        }
    }
}
import UIKit

class CustomAlertView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        // Customize the appearance of the custom alert view
        backgroundColor = .black
        layer.cornerRadius = 10
        
        // Add label for displaying the message
        let label = UILabel(frame: bounds.inset(by: UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)))
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        addSubview(label)
        self.label = label
    }
    
    var message: String? {
        get { return label.text }
        set { label.text = newValue }
    }
    
    private weak var label: UILabel!
}

extension UIViewController {
    func presentCustomAlert(message: String?, width: CGFloat, duration: TimeInterval) {
        let customAlertView = CustomAlertView(frame: CGRect(x: (view.bounds.width - width) / 2,
                                                            y: view.bounds.height - 100,
                                                            width: width,
                                                            height: 60))
        customAlertView.message = message
        view.addSubview(customAlertView)
        
        // Dismiss the custom alert after the specified duration
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            customAlertView.removeFromSuperview()
        }
    }
}
