//
//  TaskTableViewCell.swift
//  MusicPlayer
//
//  Created by elsner on 04/04/24.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var songNameLabel: UILabel!
    @IBOutlet weak var singerNameLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var playButton: UIButton!
    
    @IBOutlet weak var SongDetailsVCsongImageView: UIImageView!
    @IBOutlet weak var SongDetailsVCsongNameLabel: UILabel!
    @IBOutlet weak var SongDetailsVCsingerNameLabel: UILabel!
    @IBOutlet weak var SongDetailsVCdurationLabel: UILabel!
    @IBOutlet weak var SongDetailsVCPlayButton: UIButton!
   
    @IBOutlet weak var FavoriteSongVCsongImageView: UIImageView!
    @IBOutlet weak var FavoriteSongVCsongNameLabel: UILabel!
    @IBOutlet weak var FavoriteSongVCsingerNameLabel: UILabel!
    @IBOutlet weak var FavoriteSongVCdurationLabel: UILabel!
    @IBOutlet weak var FavoriteSongVCplayButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
