//
//  TaskCollectionViewCell.swift
//  MusicPlayer
//
//  Created by elsner on 05/04/24.
//

import UIKit

class TaskCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var songimageCollectionViewimageView: UIImageView!
    @IBOutlet weak var songimageCollectionViewAlbumnameLabel: UILabel!
    @IBOutlet weak var songimageCollectionViewdetailsButton: UIButton!

   

}
