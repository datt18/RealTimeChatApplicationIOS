//
//  SongModule.swift
//  MusicPlayer
//
//  Created by elsner on 04/04/24.
//

import Foundation
//struct Song {
//    let id: Int
//    let songName: String
//    let description: String
//    let songPhotoData: Data
//    let mp3Data: Data?
//    var duration: TimeInterval
//    var albumName: String
//    var singerName: String
//    var albumid: Int
//
////    let duration: Double
//}
class Song: Codable {
    let id: Int
    let songName: String
    let description: String
    let songPhotoData: Data
    let mp3Data: Data?
    var duration: Double
    let albumName: String
    let singerName: String
    let albumid: Int

    init(id: Int, songName: String, description: String, songPhotoData: Data, mp3Data: Data?, duration: Double, albumName: String, singerName: String, albumid: Int) {
        self.id = id
        self.songName = songName
        self.description = description
        self.songPhotoData = songPhotoData
        self.mp3Data = mp3Data
        self.duration = duration
        self.albumName = albumName
        self.singerName = singerName
        self.albumid = albumid
    }
}
struct favoriteSong {
    let songName: String
    let description: String
    let songPhotoData: Data
    let mp3Data: Data?
    var duration: TimeInterval
    var albumName: String
    var singerName: String
    var albumid: Int
}
struct Album {
        let id: Int
        let name: String
        let photoData: Data
    }
struct albumOption {
    let name: String
    let id: Int
}
