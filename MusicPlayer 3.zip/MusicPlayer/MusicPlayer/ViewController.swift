//
//  ViewController.swift
//  MusicPlayer
//
//  Created by elsner on 04/04/24.
//

import UIKit
import SQLite
import AVFoundation

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, AVAudioPlayerDelegate {
   
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var footerViewPlaybtn: UIButton!
    @IBOutlet weak var footerViewSongname: UILabel!
    
    @IBOutlet weak var footerViewSingername: UILabel!
    @IBOutlet weak var footerViewImageView: UIImageView!
    var songs: [Song] = []
    var albums: [Album] = []
       var db: Connection!
    var selectedSong: Song?
    var audioPlayer: AVAudioPlayer?
       var isPlaying = false
    var currentlyPlayingIndex: Int?
    var timer: Timer?
    var currentlyPlayingCell: TaskTableViewCell?
     var currentlyPlayingIndexPath: IndexPath?
     var currentSongTotalDuration: TimeInterval = 0
    var selectedSongDetails: Song?

    override func viewDidLoad() {
        super.viewDidLoad()
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
          do {
              db = try Connection("\(path)/albums.sqlite3")
              retrieveSongs()
              retrieveAlbums()
          } catch {
              print("Error: \(error)")
          }
        tableView.delegate = self
        tableView.dataSource = self
        collectionView.delegate = self
        collectionView.dataSource = self
        if let lastPlayedSongData = UserDefaults.standard.data(forKey: "lastPlayedSong"),
                  let lastPlayedSong = try? JSONDecoder().decode(Song.self, from: lastPlayedSongData) {
                   // Update selectedSong with the last played song
                   selectedSong = lastPlayedSong
                   // Update footer view with last played song data
                   updateFooterViewWithLastPlayedSong()
               }
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(footerViewPlaybtnTapped))
        footerViewPlaybtn.addGestureRecognizer(tapGesture)
        

    }
   
    override func viewWillAppear(_ animated: Bool) {
    }
    @objc func footerViewPlaybtnTapped() {
        guard let selectedSong = selectedSong else {
            // If no song is selected, do nothing
            return
        }
        if isPlaying {
            // If song is already playing, pause it
            audioPlayer?.pause()
            isPlaying = false
            footerViewPlaybtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
        } else {
            // If song is not playing, start playing it
            playSong(selectedSong)
        }
    }
    func playSong(_ song: Song) {
        if let mp3Data = song.mp3Data {
            do {
                audioPlayer = try AVAudioPlayer(data: mp3Data)
                audioPlayer?.delegate = self
                audioPlayer?.play()
                isPlaying = true
                footerViewPlaybtn.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
                updateFooterViewWithLastPlayedSong()
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
        }
    }

    func applicationWillTerminate(_ application: UIApplication) {
            saveLastPlayedSong() // Save the last played song
        }
        func applicationDidEnterBackground(_ application: UIApplication) {
            saveLastPlayedSong() // Save the last played song
        }
    func retrieveSongs() {
        let songsTable = Table("songs")
        let id = Expression<Int>("id")
        let songName = Expression<String>("songName")
        let description = Expression<String>("description")
        let songPhoto = Expression<Data>("songPhoto")
        let mp3File = Expression<Data>("mp3File")
        let singerName = Expression<String>("singerName")
        let albumName = Expression<String>("albumName")
        let albumid = Expression<Int>("albumId")
//        let albumPhotoData = Expression<Data>("albumPhoto")
        do {
            let fetchedSongs = try db.prepare(songsTable)
            for song in fetchedSongs {
                let newSong = Song(id: song[id],
                                   songName: song[songName],
                                   description: song[description],
                                   songPhotoData: song[songPhoto],
                                   mp3Data: song[mp3File],
                                   duration: 0,
                                   albumName: song[albumName],
                                   singerName: song[singerName],
                                   albumid: song[albumid])
                songs.append(newSong)
            }
            fetchSongDurations()
        } catch {
            print("Error retrieving songs: \(error)")
        }
    }
    func retrieveAlbums() {
        let albumsTable = Table("albums")
        let id = Expression<Int>("id")
        let albumName = Expression<String>("albumName")
        let albumPhoto = Expression<Data>("albumPhoto")

        do {
            let fetchedAlbums = try db.prepare(albumsTable)
            for album in fetchedAlbums {
                // Check if there are songs associated with the current album
                let songsTable = Table("songs")
                let albumId = Expression<Int>("albumId")
                let songCount = try db.scalar(songsTable.filter(albumId == album[id]).count)
                
                // If there are songs associated with the album, add it to the albums array
                if songCount > 0 {
                    let newAlbum = Album(id: album[id],
                                         name: album[albumName],
                                         photoData: album[albumPhoto])
                    albums.append(newAlbum)
                }
            }
        } catch {
            print("Error retrieving albums: \(error)")
        }
    }

    func fetchSongDurations() {
            for (index, song) in songs.enumerated() {
                if let mp3Data = song.mp3Data,
                   let player = try? AVAudioPlayer(data: mp3Data) {
                    let duration = player.duration / 60
                    songs[index].duration = duration
                }
            }
            tableView.reloadData()
        }
    @IBAction func BtnFavoriteSongAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
              let secondViewController = storyboard.instantiateViewController(withIdentifier: "FavoriteSongsVC") as! favoriteSongsViewController
              self.navigationController!.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func BtnAddSongAction(_ sender: Any) {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        // Add "Add Album" action
        let addAlbumAction = UIAlertAction(title: "Add Album", style: .default) { (_) in
            self.addAlbum()
        }
        alertController.addAction(addAlbumAction)

        // Add "Add Song" action
        let addSongAction = UIAlertAction(title: "Add Song", style: .default) { (_) in
            self.addSong()
        }
        alertController.addAction(addSongAction)

        // Add cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }
    func addAlbum() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
              let secondViewController = storyboard.instantiateViewController(withIdentifier: "AddAlbumVC") as! AddAlbumsViewController
              self.navigationController!.pushViewController(secondViewController, animated: true)
    }
    func addSong() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
              let secondViewController = storyboard.instantiateViewController(withIdentifier: "AddSongVC") as! AddSongDataViewController
              self.navigationController!.pushViewController(secondViewController, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return albums.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SongCollectionViewCell", for: indexPath as IndexPath) as! TaskCollectionViewCell
        let album = albums[indexPath.row]
        
        cell.songimageCollectionViewdetailsButton.tag = indexPath.row
           cell.songimageCollectionViewdetailsButton.addTarget(self, action: #selector(detailsButtonTapped(_:)), for: .touchUpInside)
        cell.songimageCollectionViewimageView.image = UIImage(data: album.photoData)
        cell.songimageCollectionViewimageView.layer.cornerRadius = 10
        cell.songimageCollectionViewimageView.layer.masksToBounds = true
        cell.songimageCollectionViewAlbumnameLabel.text = album.name
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
   
        let selectedAlbum = albums[indexPath.row]
            selectedSong = songs[indexPath.row]
                saveLastPlayedSong()
                updateFooterViewWithLastPlayedSong()
        if let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SongDetailsVC") as? SongDetailViewController
        {
            audioPlayer?.stop()
            tableView.reloadData()
         
            
            destinationVC.album = selectedAlbum
          present(destinationVC, animated: true, completion: nil)
        }
        }
    @objc func detailsButtonTapped(_ sender: UIButton) {
        let index = sender.tag
        let selectedSong = albums[index]
        
        if let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SongDetailsVC") as? SongDetailViewController
        {
            audioPlayer?.stop()
            destinationVC.album = selectedSong
          present(destinationVC, animated: true, completion: nil)
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return songs.count
      }
    
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "SongListCell", for: indexPath) as! TaskTableViewCell
          let song = songs[indexPath.row]
          cell.songNameLabel.text = song.songName
          cell.singerNameLabel.text = song.singerName
          cell.playButton.tag = indexPath.row
          cell.playButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)

                cell.playButton.addTarget(self, action: #selector(playButtonTapped(_:)), for: .touchUpInside)

        //  cell.durationLabel.text = String(format: "%.2f", song.duration)
          if let songPhoto = UIImage(data: song.songPhotoData) {
              cell.songImageView.image = songPhoto
              cell.songImageView.layer.cornerRadius = 10
              cell.songImageView.layer.masksToBounds = true
//              cell.songImageView.layer.cornerRadius =  cell.songImageView.frame.height/2
//              cell.songImageView.clipsToBounds = true
          }

          return cell
      }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Stop the currently playing song if there is one
        selectedSong = songs[indexPath.row]
        saveLastPlayedSong()
        updateFooterViewWithLastPlayedSong()
        if let player = audioPlayer, player.isPlaying {
            player.stop()
            isPlaying = false
         //   stopTimer()
            currentlyPlayingCell?.playButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
            footerViewPlaybtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)

            fetchSongDurations()
        }
        if let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SongPlayVC") as? SongPlayViewController {
            destinationVC.song = selectedSong
            destinationVC.selectedIndex = indexPath.row
            present(destinationVC, animated: true)
        }
    }
    //    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//           selectedSong = songs[indexPath.row]
//        if let destinationVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SongPlayVC") as? SongPlayViewController
//        {
//            audioPlayer?.stop()
//            destinationVC.song = selectedSong
//          present(destinationVC, animated: true, completion: nil)
//        }
//       }
    @objc func playButtonTapped(_ sender: UIButton) {
        let index = sender.tag
        let song = songs[index]
        if currentlyPlayingIndexPath == IndexPath(row: index, section: 0) {
            if let player = audioPlayer {
                if player.isPlaying {
                    player.pause()
                    isPlaying = false
                    sender.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
                   // stopTimer()
                  

                } else {
                    player.play()
                    isPlaying = true
                    sender.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal) // Change icon to pause
                    //startTimer()
                    
                }
            }
        } else {
            // If a different song is tapped
            if let mp3Data = song.mp3Data {
                do {
                    // Stop currently playing song if there is one
                    if let player = audioPlayer, player.isPlaying {
                        player.stop()
                        currentlyPlayingCell?.playButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
                    }
                    audioPlayer = try AVAudioPlayer(data: mp3Data)
                    audioPlayer?.delegate = self
                    audioPlayer?.play()
                    isPlaying = true
                 //   startTimer()
                    sender.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
                    currentlyPlayingCell = sender.superview?.superview as? TaskTableViewCell
                    currentlyPlayingIndexPath = IndexPath(row: index, section: 0)
                } catch {
                    print("Error playing audio: \(error.localizedDescription)")
                }
            }
        }
        selectedSong = songs[index]
        saveLastPlayedSong()
        updateFooterViewWithLastPlayedSong()
    }
    func saveLastPlayedSong() {
        if let selectedSong = selectedSong,
           let encodedData = try? JSONEncoder().encode(selectedSong) {
            UserDefaults.standard.set(encodedData, forKey: "lastPlayedSong")
        }
    }
    func updateFooterViewWithLastPlayedSong() {
           guard let lastPlayedSong = selectedSong else {
               // If no last played song available, update footer view with default values
               footerViewSongname.text = "No song played"
               footerViewSingername.text = ""
               footerViewImageView.image = nil
               footerViewPlaybtn.setImage(nil, for: .normal)
               return
           }
           // Update footer view with last played song data
           footerViewSongname.text = lastPlayedSong.songName
           footerViewSingername.text = lastPlayedSong.singerName
        if let songPhoto = UIImage(data: lastPlayedSong.songPhotoData) {
            footerViewImageView.image = songPhoto
            footerViewImageView.layer.cornerRadius = 10
            footerViewImageView.layer.masksToBounds = true
        }
           if isPlaying {
               footerViewPlaybtn.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
           } else {
               footerViewPlaybtn.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
           }
        let randomRed = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
        let randomGreen = CGFloat(arc4random_uniform(128)) / 255.0 // Limiting the range to make it darker
        let randomBlue = CGFloat(arc4random_uniform(256)) / 255.0 // Limiting the range to make it darker
        let randomAlpha = CGFloat(arc4random_uniform(256)) / 255.0
        let randomColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: randomAlpha)
        footerView.backgroundColor = randomColor
       }
   
//        func startTimer() {
//            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateDurationLabels), userInfo: nil, repeats: true)
//        }
//
//        func stopTimer() {
//            timer?.invalidate()
//            timer = nil
//        }
//        @objc func updateDurationLabels() {
//            if let player = audioPlayer {
//                let currentTime = player.currentTime
//                if let cell = currentlyPlayingCell {
//                    cell.durationLabel.text = String(format: "%.2f", currentTime / 60) // Update current playing song duration
//                }
//            }
//        }
}
