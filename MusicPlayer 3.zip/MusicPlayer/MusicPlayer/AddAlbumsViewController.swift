//
//  AddAlbumsViewController.swift
//  MusicPlayer
//
//  Created by elsner on 08/04/24.
//

import UIKit
import SQLite
class AddAlbumsViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    @IBOutlet weak var albumNameTextField: UITextField!
      @IBOutlet weak var singerNameTextField: UITextField!
      @IBOutlet weak var descriptionTextField: UITextField!
      @IBOutlet weak var albumImageView: UIImageView!
      
    var db: Connection!

    override func viewDidLoad() {
        super.viewDidLoad()
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
                do {
                    db = try Connection("\(path)/albums.sqlite3") // Use a different database name
                    createAlbumsTable() // Create albums table if it doesn't exist
                } catch {
                    print("Error: \(error)")
                }
    
    }
    func createAlbumsTable() {
            let albums = Table("albums")
            let id = Expression<Int>("id")
            let albumName = Expression<String>("albumName")
            let singerName = Expression<String>("singerName")
            let description = Expression<String>("description")
            let albumPhoto = Expression<Data>("albumPhoto")
            
            do {
                try db.run(albums.create(ifNotExists: true) { table in
                    table.column(id, primaryKey: .autoincrement)
                    table.column(albumName)
                    table.column(singerName)
                    table.column(description)
                    table.column(albumPhoto)
                })
            } catch {
                print("Error creating albums table: \(error)")
            }
        }
    @IBAction func choosePhotoButtonTapped(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
       }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            albumImageView.image = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    @IBAction func savealbum(_ sender: UIButton) {
        guard let albumName = albumNameTextField.text,
              let singerName = singerNameTextField.text,
              let description = descriptionTextField.text,
              let albumPhotoData = albumImageView.image?.pngData() else {
            return
        }
        
        let albums = Table("albums")
        let albumNameExp = Expression<String>("albumName")
        let singerNameExp = Expression<String>("singerName")
        let descriptionExp = Expression<String>("description")
        let albumPhotoExp = Expression<Data>("albumPhoto")
        
        let insert = albums.insert(albumNameExp <- albumName,
                                   singerNameExp <- singerName,
                                   descriptionExp <- description,
                                   albumPhotoExp <- albumPhotoData)
        
        do {
            try db.run(insert)
            print("Album data inserted successfully")
//
            if let addSongVC = navigationController?.viewControllers.first(where: { $0 is AddSongDataViewController }) as? AddSongDataViewController {
                        addSongVC.fetchAlbums()
                    }
                navigationController?.popViewController(animated: true)
//            navigationController?.popViewController(animated: true)
        } catch {
            print("Error inserting album data: \(error)")
        }
    }
}
