//
//  RegistrationPageViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3
class RegistrationPageViewController: UIViewController ,UIImagePickerControllerDelegate & UINavigationControllerDelegate{
    @IBOutlet weak var emailTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var UserNameTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var nameTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var NumberTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var PasswordtextFieldRegistrationPage: UITextField!
    @IBOutlet weak var btn_registrationRegistrationPage: UIButton!
    @IBOutlet weak var lbl_LoginRegistrationPage: UILabel!
    @IBOutlet weak var btn_ProfilePhotoUploadRegVC: UIButton!
    @IBOutlet weak var Img_ProfilePhotoSelectedRegVC: UIImageView!
    var db: OpaquePointer?
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        
        btn_registrationRegistrationPage.layer.cornerRadius = 10
        btn_registrationRegistrationPage.layer.masksToBounds = true
        readData()
        let attributedString = NSMutableAttributedString(string: "have an Account? Log In!")
        let termsRange = (attributedString.string as NSString).range(of: "Log In!")
        attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 17), range: termsRange)
        lbl_LoginRegistrationPage.attributedText = attributedString
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped1))
        lbl_LoginRegistrationPage.isUserInteractionEnabled = true
        lbl_LoginRegistrationPage.addGestureRecognizer(tapGesture)
    }
    
       @objc func labelTapped1(sender: UITapGestureRecognizer) {
           print("click")
           let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "LoginVC") as! ViewController
           self.navigationController!.pushViewController(secondViewController, animated: true)
           
       }
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
           createTable()
       }

       func createTable() {
//           let createTableQuery = "CREATE TABLE IF NOT EXISTS Users (userId INTEGER PRIMARY KEY AUTOINCREMENT, emailId TEXT UNIQUE, password TEXT, name TEXT, username TEXT UNIQUE, number TEXT, photo BLOB);"
           let createTableQuery = "CREATE TABLE IF NOT EXISTS Users (userId INTEGER PRIMARY KEY AUTOINCREMENT, emailId TEXT UNIQUE, password TEXT, name TEXT, username TEXT , number TEXT, photo BLOB);"
           if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK {
               print("Error creating table")
               return
           }
       }
    @IBAction func choosePhotoButtonTapped(_ sender: UIButton) {
           let imagePickerController = UIImagePickerController()
           imagePickerController.delegate = self
           imagePickerController.sourceType = .photoLibrary
           present(imagePickerController, animated: true, completion: nil)
       }

       func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
           if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
               Img_ProfilePhotoSelectedRegVC.image = pickedImage
           }
           dismiss(animated: true, completion: nil)
       }

       @IBAction func signUpButtonTapped(_ sender: UIButton) {
//           insertData()
           guard validateEmail(emailTextFieldRegistrationPage.text),
                    validateName(nameTextFieldRegistrationPage.text),
                    validateMobileNumber(NumberTextFieldRegistrationPage.text),
                 validateUsername(UserNameTextFieldRegistrationPage.text),
           validatePassword(PasswordtextFieldRegistrationPage.text) else {
                  return
              }
              
              insertData()
           print("new")
          }

          func validateEmail(_ email: String?) -> Bool {
              guard let email = email, !email.isEmpty else {
                  showAlert(message: "Please enter an email.")
                  return false
              }
              
              guard isValidEmail(email) else {
                  showAlert(message: "Please enter a valid email.")
                  return false
              }
              
              return true
          }

          func isValidEmail(_ email: String) -> Bool {
              // Regular expression for email validation
              let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
              let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
              return emailPredicate.evaluate(with: email)
          }

          func validatePassword(_ password: String?) -> Bool {
              guard let password = password, !password.isEmpty else {
                  showAlert(message: "Please enter a password.")
                  return false
              }
              
              // You can add more password validation logic here if needed
              
              return true
          }

          func validateName(_ name: String?) -> Bool {
              guard let name = name, !name.isEmpty else {
                  showAlert(message: "Please enter your username.")
                  return false
              }
              
              return true
          }
    func validateUsername(_ name: String?) -> Bool {
        guard let name = name, !name.isEmpty else {
            showAlert(message: "Please enter your name.")
            return false
        }
        
        return true
    }

          func validateMobileNumber(_ number: String?) -> Bool {
              guard let number = number, !number.isEmpty else {
                  showAlert(message: "Please enter your mobile number.")
                  return false
              }
              
              guard number.count == 10 && number.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil else {
                  showAlert(message: "Please enter a valid 10-digit mobile number.")
                  return false
              }
              
              return true
          }

        func showAlert(message: String) {
              let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
              present(alert, animated: true, completion: nil)
          }

       
    func insertData() {
        guard let email = emailTextFieldRegistrationPage.text,
              let password = PasswordtextFieldRegistrationPage.text,
              let name = nameTextFieldRegistrationPage.text,
              let username = UserNameTextFieldRegistrationPage.text,
              let number = NumberTextFieldRegistrationPage.text,
              let photo = Img_ProfilePhotoSelectedRegVC.image?.pngData() else {
            return
        }

        let insertQuery = "INSERT INTO Users (emailId, password, name, username, number, photo) VALUES (?, ?, ?, ?, ?, ?);"
        var statement: OpaquePointer?
        if sqlite3_prepare(db, insertQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing insert statement")
            return
        }

        if sqlite3_bind_text(statement, 1, (email as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_text(statement, 2, (password as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_text(statement, 3, (name as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_text(statement, 4, (username as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_text(statement, 5, (number as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_blob(statement, 6, (photo as NSData).bytes, Int32(photo.count), nil) != SQLITE_OK {
            print("Error binding values")
            return
        }

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error inserting user")
            return
        }

        print("User inserted successfully")
        showAlert(message: "User Registration successfully Done")
        sqlite3_finalize(statement)

    }
       deinit {
           sqlite3_close(db)
       }
    func readData() {
        let query = "SELECT * FROM Users;"
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let userId = sqlite3_column_int(statement, 0)
                let email = String(cString: sqlite3_column_text(statement, 1))
                let password = String(cString: sqlite3_column_text(statement, 2))
                let name = String(cString: sqlite3_column_text(statement, 3))
                let username = String(cString: sqlite3_column_text(statement, 4))
                let number = String(cString: sqlite3_column_text(statement, 5))
                
                let photoData = sqlite3_column_blob(statement, 6)
                let photoDataSize = sqlite3_column_bytes(statement, 6)
                let photo = UIImage(data: Data(bytes: photoData!, count: Int(photoDataSize)))
                
                print("User ID: \(userId), Email: \(email), Password: \(password), Name: \(name), Username: \(username), Number: \(number)")
                
            }
        } else {
            print("Error reading data")
        }
        
        sqlite3_finalize(statement)
    }
}
