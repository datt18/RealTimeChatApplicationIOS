//
//  ViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3

class ViewController: UIViewController {
    
    @IBOutlet weak var emailTextFieldLoginPage: UITextField!
    @IBOutlet weak var passwordTextFieldLoginPage: UITextField!
    @IBOutlet weak var lbl_SignUpLoginpage: UILabel!
    @IBOutlet weak var btn_loginLoginPage: UIButton!
    var db: OpaquePointer?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        checkLoggedInUser()
        openDatabase()
        btn_loginLoginPage.layer.cornerRadius = 10
        btn_loginLoginPage.layer.masksToBounds = true
        navigationItem.hidesBackButton = true
        let attributedString = NSMutableAttributedString(string: "Dont't have an Account? Sign Up!")
        let termsRange = (attributedString.string as NSString).range(of: "Sign Up!")
        attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 17), range: termsRange)
        lbl_SignUpLoginpage.attributedText = attributedString
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped))
        lbl_SignUpLoginpage.isUserInteractionEnabled = true
        lbl_SignUpLoginpage.addGestureRecognizer(tapGesture)
    }
//    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.isNavigationBarHidden = true
//    }
    
    func checkLoggedInUser() {
            if isLoggedIn() {
                navigateToHomeScreen()
            }
        }
    func loginSuccess(userId: Int) {
      
        UserDefaults.standard.set(true, forKey: "isLoggedIn")
        UserDefaults.standard.set(userId, forKey: "userId")
        print(UserDefaults.standard.value(forKey: "isLoggedIn"))
        UserDefaults.standard.synchronize()
        // Set userId in UserDefaults
        navigateToHomeScreen()
    }
    
    func isLoggedIn() -> Bool {
        return UserDefaults.standard.bool(forKey: "isLoggedIn")
    }
    
    func navigateToHomeScreen() {
        performSegue(withIdentifier: "homepage", sender: nil)

//        let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageViewController
//        let userId = UserDefaults.standard.value(forKey: "userId") as? Int
//        secondViewController.userId = userId!
//        self.navigationController?.pushViewController(secondViewController, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "homepage" {
            if let addDataViewController = segue.destination as? HomePageViewController {
                addDataViewController.db = self.db

                if let userId = UserDefaults.standard.value(forKey: "userId") as? Int {
                    addDataViewController.userId = userId
                }
            }
        }
    }

    @objc func labelTapped(sender: UITapGestureRecognizer) {
        print("click")
            let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "RegVC") as! RegistrationPageViewController
            self.navigationController?.pushViewController(secondViewController, animated: true)
        
    }
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let email = emailTextFieldLoginPage.text, let password = passwordTextFieldLoginPage.text else {
            return
        }
        loginUser(email: email, password: password)

        }
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
       }
    func loginUser(email: String, password: String) {
        guard let email = emailTextFieldLoginPage.text,
              let password = passwordTextFieldLoginPage.text else {
            return
        }

        let query = "SELECT * FROM Users WHERE emailId = ? AND password = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (email as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (password as NSString).utf8String, -1, nil)

            if sqlite3_step(statement) == SQLITE_ROW {
                print("Login successful")
                let userId = Int(sqlite3_column_int(statement, 0))
                loginSuccess(userId: userId)
               print(userId)
                self.performSegue(withIdentifier: "homepage", sender: self)
            } else {
                print("Invalid credentials")
                showAlert(message: "Please enter a valid credentials.")

            }
        } else {
            print("Error preparing statement")
        }
        sqlite3_finalize(statement)
    }

    deinit {
        sqlite3_close(db)
    }
    func showAlert(message: String) {
          let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
          alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
          present(alert, animated: true, completion: nil)
      }

    }



