//
//  EditPageViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 18/03/24.
//
import UIKit
import SQLite3

class EditPageViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    @IBOutlet weak var EditVCEmailTextField: UITextField!
    @IBOutlet weak var EditVCnameTextField: UITextField!
    @IBOutlet weak var EditVCusernameTextField: UITextField!
    @IBOutlet weak var EditVCNumberTextField: UITextField!
    @IBOutlet weak var EditVCphotoImageView: UIImageView!
    
    var db: OpaquePointer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        fetchCurrentUserInEditVC()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        openDatabase()
        fetchCurrentUserInEditVC()
    }
    
    @IBAction func choosePhotoButtonEditVCTapped(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            EditVCphotoImageView.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
       }
    func fetchCurrentUserInEditVC() {
           guard let userId = UserDefaults.standard.value(forKey: "userId") as? Int else {
               return
           }

           let query = "SELECT name, username, photo, emailId, number FROM Users WHERE userId = ?;"
           var statement: OpaquePointer?

           if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
               if sqlite3_bind_int(statement, 1, Int32(userId)) == SQLITE_OK {
                   if sqlite3_step(statement) == SQLITE_ROW {
                       let name = String(cString: sqlite3_column_text(statement, 0))
                       let username = String(cString: sqlite3_column_text(statement, 1))
                       let photoData = sqlite3_column_blob(statement, 2)
                       let photoDataSize = sqlite3_column_bytes(statement, 2)
                       let photo = UIImage(data: Data(bytes: photoData!, count: Int(photoDataSize)))
                       let email = String(cString: sqlite3_column_text(statement, 3))
                       let number = String(cString: sqlite3_column_text(statement, 4))

                       EditVCEmailTextField.text = email
                       EditVCnameTextField.text = name
                       EditVCusernameTextField.text = username
                       EditVCNumberTextField.text = number
                       EditVCphotoImageView.image = photo
                   }
               }
           }

           sqlite3_finalize(statement)
       }
    @IBAction func saveButtonEditVCTapped(_ sender: UIButton) {
        updateData()
}
    func updateData() {
        guard let userId = UserDefaults.standard.value(forKey: "userId") as? Int else {
            return
        }
        
        let name = EditVCnameTextField.text ?? ""
        let username = EditVCusernameTextField.text ?? ""
        let email = EditVCEmailTextField.text ?? ""
        let number = EditVCNumberTextField.text ?? ""
        let photoData = EditVCphotoImageView.image?.jpegData(compressionQuality: 1.0)
        
        let query = "UPDATE Users SET name = ?, username = ?, emailId = ?, number = ?, photo = ? WHERE userId = ?;"
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (name as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (username as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 3, (email as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 4, (number as NSString).utf8String, -1, nil)
            
            if let imageData = photoData {
                sqlite3_bind_blob(statement, 5, (imageData as NSData).bytes, Int32(imageData.count), nil)
            } else {
                sqlite3_bind_blob(statement, 5, nil, -1, nil)
            }
            
            sqlite3_bind_int(statement, 6, Int32(userId))
            
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Data updated successfully.")
                self.navigationController?.popViewController(animated: true)
            } else {
                print("Error updating data.")
            }
        } else {
            print("Error preparing update statement.")
        }
        
        sqlite3_finalize(statement)
    }

   
    }
       
        
