//
//  HomePageTableViewCell.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 18/03/24.
//

import UIKit

class HomePageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lbl_usernameHomePage: UILabel!
    @IBOutlet weak var lbl_LocationHomePage: UILabel!
    @IBOutlet weak var lbl_DescriptionHomepage: UILabel!
    @IBOutlet weak var img_ImageHomePage: UIImageView!
    @IBOutlet weak var img_iconImageHomePage: UIImageView!
    @IBOutlet weak var SearchPageUsernameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
