//
//  EditPostDataViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 18/03/24.
//

import UIKit
import SQLite3
class EditPostDataViewController: UIViewController,UIImagePickerControllerDelegate & UINavigationControllerDelegate  {
    @IBOutlet weak var EditPostVClocationTextField: UITextField!
    @IBOutlet weak var EditPostVCdescriptionTextField: UITextField!
    @IBOutlet weak var EditPostVCimageView: UIImageView!
    
    var db: OpaquePointer?

    var selectedID: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        fetchPostData()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        openDatabase()
        fetchPostData()
    }
    @IBAction func choosePhotoButtonEditVCTapped(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            EditPostVCimageView.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    func openDatabase() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("users.sqlite")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
    }
    func fetchPostData() {
        guard let database = db else {
                    print("Database not initialized.")
                    return
                }

           let query = "SELECT location, description, photo FROM UserData WHERE dataId = ?;"
           var statement: OpaquePointer?

           if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
               sqlite3_bind_int(statement, 1, Int32(selectedID))

               if sqlite3_step(statement) == SQLITE_ROW {
                   if let location = sqlite3_column_text(statement, 0),
                       let description = sqlite3_column_text(statement, 1),
                       let photoData = sqlite3_column_blob(statement, 2) {

                       let locationString = String(cString: location)
                       let descriptionString = String(cString: description)
                       let photoDataSize = Int(sqlite3_column_bytes(statement, 2))
                       let photo = UIImage(data: Data(bytes: photoData, count: photoDataSize))

                       // Populate UI elements with fetched data
                       EditPostVClocationTextField.text = locationString
                       EditPostVCdescriptionTextField.text = descriptionString
                       EditPostVCimageView.image = photo
                   }
               }
           } else {
               print("Error fetching post data.")
           }

           sqlite3_finalize(statement)
       }

       // Function to update the edited post data in the database
    func updatePostData() {
        guard let database = db else {
            print("Database not initialized.")
            return
        }
        
        let location = EditPostVClocationTextField.text ?? ""
        let description = EditPostVCdescriptionTextField.text ?? ""
        let photo = EditPostVCimageView.image
        
        guard let photoData = photo?.jpegData(compressionQuality: 1.0) else {
            print("Failed to convert image to data.")
            return
        }
        
        let updateQuery = "UPDATE UserData SET location = ?, description = ?, photo = ? WHERE dataId = ?;"
        var updateStatement: OpaquePointer?
        
        if sqlite3_prepare_v2(database, updateQuery, -1, &updateStatement, nil) == SQLITE_OK {
            sqlite3_bind_text(updateStatement, 1, (location as NSString).utf8String, -1, nil)
            sqlite3_bind_text(updateStatement, 2, (description as NSString).utf8String, -1, nil)
            sqlite3_bind_blob(updateStatement, 3, (photoData as NSData).bytes, Int32(photoData.count), nil)
            sqlite3_bind_int(updateStatement, 4, Int32(selectedID))
            
            if sqlite3_step(updateStatement) == SQLITE_DONE {
                print("Post data updated successfully.")
                self.navigationController?.popViewController(animated: true)

            } else {
                print("Error updating post data.")
            }
        } else {
            print("Error preparing update statement.")
        }
        
        sqlite3_finalize(updateStatement)
    }
    
    @IBAction func saveChanges(_ sender: UIButton) {
        updatePostData()
     
    }
    }
    
