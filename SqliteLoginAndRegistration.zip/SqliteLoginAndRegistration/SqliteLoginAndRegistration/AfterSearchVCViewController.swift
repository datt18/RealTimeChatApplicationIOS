//
//  AfterSearchVCViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 20/03/24.
//

import UIKit
import SQLite3
class AfterSearchVCViewController: UIViewController {

    @IBOutlet weak var AfterSearchVCProfileImageView: UIImageView!
    @IBOutlet weak var AfterSearchVCProfilename: UILabel!
    @IBOutlet weak var AfterSearchVCProfileUsername: UILabel!
    var db: OpaquePointer?
    var userID: Int?

    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        print("uid",userID)
     //   fetchUserData()
    }
    override func viewWillAppear(_ animated: Bool) {
                self.navigationController?.isNavigationBarHidden = false

    }
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
       }
    
    
}
