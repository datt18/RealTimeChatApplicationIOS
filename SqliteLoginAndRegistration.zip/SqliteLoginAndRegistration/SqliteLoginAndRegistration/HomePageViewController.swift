//
//  HomePageViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3
class HomePageViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    var db: OpaquePointer?
    var userId: Int = 0

//     var userData: [(dataId: Int, location: String, description: String, photo: UIImage?)] = []
    var userData: [(dataId: Int, location: String, description: String, photo: UIImage?, username: String, Profilephoto: UIImage?)] = []
   // var userData: [(userId: Int, username: String, userProfilePhoto: UIImage?, location: String, description: String, photo: UIImage?)] = []
    @IBOutlet weak var homepagetableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        fetchData()
           homepagetableview.delegate = self
           homepagetableview.dataSource = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//self.navigationItem.hidesBackButton = true
        self.navigationController?.isNavigationBarHidden = false
        self.openDatabase()
        self.fetchData()

    }
    
    @IBAction func AddPostButtonClick(_ sender: UIButton) {
        performSegue(withIdentifier: "AddPostVC", sender: self)
        }
    func loginSuccess(userId: Int) {
//        print(UserDefaults.standard.value(forKey: "isLoggedIn"))
        UserDefaults.standard.set(true, forKey: "isLoggedIn")
        UserDefaults.standard.set(userId, forKey: "userId")
        
        UserDefaults.standard.synchronize()
        navigateToHomeScreen()
    }
    func navigateToHomeScreen() {
        performSegue(withIdentifier: "AddPostVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddPostVC" {
            if let addDataViewController = segue.destination as? AddPostViewController {
                addDataViewController.db = self.db
           
                if let userId = UserDefaults.standard.value(forKey: "userId") as? Int {
                    addDataViewController.userId = userId
                }
            }
        }
    }
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
       }
    func fetchData() {
        let query = """
        SELECT UserData.*, Users.username, Users.photo
        FROM UserData
        INNER JOIN Users ON UserData.userId = Users.userId;
        """
        var statement: OpaquePointer?
        userData.removeAll()

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let dataId = sqlite3_column_int(statement, 0)
                let location = String(cString: sqlite3_column_text(statement, 2))
                let description = String(cString: sqlite3_column_text(statement, 3))
                let photoData = sqlite3_column_blob(statement, 4)
                let photoDataSize = sqlite3_column_bytes(statement, 4)
                let photo = UIImage(data: Data(bytes: photoData!, count: Int(photoDataSize)))
              
                let ProfilephotoData = sqlite3_column_blob(statement, 6)
                let ProfilephotoDataSize = sqlite3_column_bytes(statement, 6)
                let Profilephoto = UIImage(data: Data(bytes: ProfilephotoData!, count: Int(ProfilephotoDataSize)))


                let username = String(cString: sqlite3_column_text(statement, 5))

                // Now you have your data, you can use it as needed
                print("DataId: \(dataId), Location: \(location), Description: \(description), Username: \(username)")
                userData.append((Int(dataId), location, description, photo, username, Profilephoto))
                // You can also use 'profilePhoto' which is a UIImage object containing the profile photo
            }
        } else {
            print("Error preparing statement")
        }

        sqlite3_finalize(statement)
        homepagetableview.reloadData()
    }

      func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return userData.count
      }

      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "HomePageTableCell", for: indexPath) as! HomePageTableViewCell
          let data = userData[indexPath.row]
          
          // Configure cell with user data and added data
        //  cell.lbl_usernameHomePage.text = data.username
         // cell.img_iconImageHomePage.image = data.userProfilePhoto
          cell.backgroundColor = UIColor.white
          cell.layer.borderColor = UIColor.lightGray.cgColor
          cell.layer.borderWidth = 0.4
          cell.lbl_LocationHomePage.text = data.location
          cell.lbl_DescriptionHomepage.text = data.description
          cell.img_ImageHomePage.image = data.photo
          cell.img_iconImageHomePage.image = data.Profilephoto
          cell.lbl_usernameHomePage.text = data.username
          cell.img_iconImageHomePage.layer.cornerRadius = cell.img_iconImageHomePage.frame.height/2
          cell.img_iconImageHomePage.layer.masksToBounds = true
          return cell
      }
  }

//    func fetchData() {
//      let query = "SELECT * FROM UserData;"
//      var statement: OpaquePointer?
//        userData.removeAll()
//
//      if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
//          while sqlite3_step(statement) == SQLITE_ROW {
//              let dataId = sqlite3_column_int(statement, 0)
//              let location = String(cString: sqlite3_column_text(statement, 2))
//              let description = String(cString: sqlite3_column_text(statement, 3))
//
//              let photoData = sqlite3_column_blob(statement, 4)
//              let photoDataSize = sqlite3_column_bytes(statement, 4)
//              let photo = UIImage(data: Data(bytes: photoData!, count: Int(photoDataSize)))
//
//              userData.append((Int(dataId), location, description, photo))
//          }
//      } else {
//          print("Error reading data")
//      }
//
//      sqlite3_finalize(statement)
//      homepagetableview.reloadData()
//  }
