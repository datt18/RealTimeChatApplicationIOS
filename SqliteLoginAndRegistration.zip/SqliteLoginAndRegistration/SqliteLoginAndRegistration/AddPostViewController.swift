//
//  AddPostViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3
class AddPostViewController: UIViewController,UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    @IBOutlet weak var AddDataVClocationTextField: UITextField!
    @IBOutlet weak var AddDataVCdescriptionTextField: UITextField!
    @IBOutlet weak var AddDataVCimageView: UIImageView!
    
    @IBOutlet weak var btn_homepageSavePost: UIButton!
    var db: OpaquePointer?
    var userId: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        fetchData()
//        AddDataVCimageView.layer.cornerRadius = AddDataVCimageView.frame.height/2
//        AddDataVCimageView.layer.masksToBounds = true
        btn_homepageSavePost.layer.cornerRadius = 10
        btn_homepageSavePost.layer.masksToBounds = true
//        print(userId)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    func openDatabase() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("users.sqlite")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
        createPostTable()
    }
    func createPostTable() {
        let createTableQuery = "CREATE TABLE IF NOT EXISTS UserData (dataId INTEGER PRIMARY KEY AUTOINCREMENT,userId INTEGER,location TEXT,description TEXT,photo BLOB,FOREIGN KEY (userId) REFERENCES Users(userId));"
        if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creating table")
            return
        }
    }

    
    @IBAction func uploadButtonTapped(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            AddDataVCimageView.contentMode = .scaleAspectFit
            AddDataVCimageView.image = pickedImage
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func setLoggedInState(_ isLoggedIn: Bool) {
            UserDefaults.standard.set(isLoggedIn, forKey: "isLoggedIn")
        }
        func isLoggedIn() -> Bool {
            return UserDefaults.standard.bool(forKey: "isLoggedIn")
        }
    
    
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let location = AddDataVClocationTextField.text, let description = AddDataVCdescriptionTextField.text, let photo = AddDataVCimageView.image?.pngData() else {
                    return
                }
                
             
                insertData(location: location, description: description, photo: photo)
    }
    func insertData(location: String, description: String, photo: Data) {
        let insertQuery = "INSERT INTO UserData (userId, location, description, photo) VALUES (?, ?, ?, ?);"
        var statement: OpaquePointer?
//
//        guard let userId = UserDefaults.standard.value(forKey: "userId") as? Int else {
//            print("User ID not found")
//            return
//        }
        
        if sqlite3_prepare(db, insertQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing insert statement")
            return
        }
        
        if sqlite3_bind_int(statement, 1, Int32(userId)) != SQLITE_OK ||
            sqlite3_bind_text(statement, 2, (location as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_text(statement, 3, (description as NSString).utf8String, -1, nil) != SQLITE_OK ||
            sqlite3_bind_blob(statement, 4, (photo as NSData).bytes, Int32(photo.count), nil) != SQLITE_OK {
            print("Error binding values")
            return
        }
        
        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error inserting data")
            return
        }
        
        print("Data inserted successfully")
        
        self.navigationController?.popViewController(animated: true)

        sqlite3_finalize(statement)
    }
    func fetchData() {
        let query = "SELECT * FROM UserData WHERE userId = ?;"
        var statement: OpaquePointer?
        
        if sqlite3_prepare(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing select statement")
            return
        }
        
        if sqlite3_bind_int(statement, 1, Int32(userId)) != SQLITE_OK {
            print("Error binding userId")
            return
        }
        
        while sqlite3_step(statement) == SQLITE_ROW {
            let dataId = sqlite3_column_int(statement, 0)
            let location = String(cString: sqlite3_column_text(statement, 2))
            let description = String(cString: sqlite3_column_text(statement, 3))
            
            // Assuming your photo is stored as BLOB data and you want to convert it back to UIImage
            let photoData = Data(bytes: sqlite3_column_blob(statement, 4), count: Int(sqlite3_column_bytes(statement, 4)))
            let photo = UIImage(data: photoData)
            
            // Now you have your data, you can use it as needed
            print("DataId: \(dataId), Location: \(location), Description: \(description)")
            
            // You can also use 'photo' which is a UIImage object containing the photo
        }
        
        sqlite3_finalize(statement)
    }

    

}

