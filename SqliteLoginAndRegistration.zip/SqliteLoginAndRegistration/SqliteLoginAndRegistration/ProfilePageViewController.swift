//
//  ProfilePageViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3
class ProfilePageViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    @IBOutlet weak var lbl_profileVCname: UILabel!
    @IBOutlet weak var lbl_profileVCUsername: UILabel!
    @IBOutlet weak var img_profileVCProfileImage: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var dropdownButton: UIButton!
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    var userData: [(dataId: Int, location: String, description: String, photo: UIImage?)] = []
    var db: OpaquePointer?
    let dropdownMenu: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.isHidden = true
        stackView.backgroundColor = .white
        return stackView
    }()

    let blurEffectView: UIVisualEffectView = {
           let blurEffect = UIBlurEffect(style: .light)
           let blurEffectView = UIVisualEffectView(effect: blurEffect)
           blurEffectView.alpha = 0.4
           return blurEffectView
       }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(dropdownButton)
        view.addSubview(blurEffectView)
        blurEffectView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.8)
        blurEffectView.isHidden = true
        view.addSubview(dropdownMenu)
        setupConstraints()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
               view.addGestureRecognizer(tapGestureRecognizer)
        img_profileVCProfileImage.layer.cornerRadius = img_profileVCProfileImage.frame.height/2
        img_profileVCProfileImage.layer.masksToBounds = true
        openDatabase()
        fetchCurrentUser()
        fetchCollectionViewData(for: UserDefaults.standard.integer(forKey: "userId"))
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.reloadData()
        navigationItem.hidesBackButton = true
        self.navigationController?.isNavigationBarHidden = true
        collectionView.delegate = self
        collectionView.dataSource = self
        screenSize = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: screenWidth/3, height: screenHeight/6)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 2
        collectionView!.collectionViewLayout = layout

    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        dropdownMenu.isHidden = true
        blurEffectView.isHidden = true
        self.openDatabase()
        self.fetchCurrentUser()
    fetchCollectionViewData(for: UserDefaults.standard.integer(forKey: "userId"))
    }
    func setupConstraints() {
        dropdownButton.translatesAutoresizingMaskIntoConstraints = false
        dropdownMenu.translatesAutoresizingMaskIntoConstraints = false
        blurEffectView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            dropdownButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: -20),
            dropdownButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0),

            dropdownMenu.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 45),
            dropdownMenu.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -3),
            blurEffectView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurEffectView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            dropdownMenu.widthAnchor.constraint(equalToConstant: 120),
            dropdownMenu.heightAnchor.constraint(equalToConstant: 80),
            blurEffectView.topAnchor.constraint(equalTo: view.topAnchor),
            blurEffectView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
        ])
    }
    @IBAction func DropdownClickAction(_ sender: UIButton) {
//        UserDefaults.standard.set(false, forKey: "isLoggedIn")
//        UserDefaults.standard.removeObject(forKey: "userId")
//
      //  navigateToLoginScreen()
        UIView.animate(withDuration: 0.3) {
            self.blurEffectView.isHidden = !self.dropdownMenu.isHidden
                   self.dropdownMenu.isHidden.toggle()
                   self.updateDropdownMenu()
               }
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
          let location = sender.location(in: collectionView)
        if !dropdownMenu.isHidden {
            UIView.animate(withDuration: 0.3) {
                self.dropdownMenu.isHidden = true
                self.blurEffectView.isHidden = true
           
            }
        } else {

          if let indexPath = collectionView.indexPathForItem(at: location) {
              let selectedData = userData[indexPath.row]
              let selectedDocumentID = selectedData.dataId
              print("Selected Document ID: \(selectedDocumentID)")
              if let imageDetailVC = storyboard?.instantiateViewController(withIdentifier: "PostEditPageVC") as? EditPostDataViewController {
                  imageDetailVC.selectedID = selectedDocumentID
                  navigationController?.pushViewController(imageDetailVC, animated: true)
              }
              
          }
          }
        
      }

    func updateDropdownMenu() {
        dropdownMenu.removeAllArrangedSubviews()
        let editButton = UIButton()
        editButton.setTitle("Edit Profile", for: .normal)
        editButton.setTitleColor(.black, for: .normal)
        editButton.addTarget(self, action: #selector(editButtonTapped), for: .touchUpInside)
        let logoutButton = UIButton()
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.setTitleColor(.black, for: .normal)
        logoutButton.addTarget(self, action: #selector(logoutButtonTapped), for: .touchUpInside)

//        logoutButton.setContentHuggingPriority(.required, for: .horizontal)
//        logoutButton.setContentCompressionResistancePriority(.required, for: .horizontal)

        dropdownMenu.addArrangedSubview(editButton)
        dropdownMenu.addArrangedSubview(logoutButton)
    }

    @objc func editButtonTapped() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let destinationVC = storyboard.instantiateViewController(withIdentifier: "Editpage") as? EditPageViewController {
                destinationVC.db = self.db

                self.navigationController?.pushViewController(destinationVC, animated: true)
            }
            print("Edit button tapped")
        }
    @objc func logoutButtonTapped() {
        let confirmLogoutAlert = UIAlertController(title: "Confirm Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)

        let cancelConfirmationAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        confirmLogoutAlert.addAction(cancelConfirmationAction)

        let confirmAction = UIAlertAction(title: "Yes", style: .default) { _ in
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            UserDefaults.standard.removeObject(forKey: "userId")
            self.navigateToLoginScreen()

        }
        confirmLogoutAlert.addAction(confirmAction)
        self.present(confirmLogoutAlert, animated: true, completion: nil)
        print("Logout button tapped")
    }

    func navigateToLoginScreen() {
           if let loginVC = storyboard?.instantiateViewController(withIdentifier: "LoginVC") {
               navigationController?.setViewControllers([loginVC], animated: true)
           }
       }
    func openDatabase() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("users.sqlite")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
    }
    func fetchCurrentUser() {
        guard let userId = UserDefaults.standard.value(forKey: "userId") as? Int else {
            return
        }
        
        let query = "SELECT name, username, photo FROM Users WHERE userId = ?;"
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_bind_int(statement, 1, Int32(userId)) == SQLITE_OK {
                if sqlite3_step(statement) == SQLITE_ROW {
                    let name = String(cString: sqlite3_column_text(statement, 0))
                    let username = String(cString: sqlite3_column_text(statement, 1))
                    let photoData = sqlite3_column_blob(statement, 2)
                    let photoDataSize = sqlite3_column_bytes(statement, 2)
                    let photo = UIImage(data: Data(bytes: photoData!, count: Int(photoDataSize)))
                    
                    lbl_profileVCUsername.text = username
                    img_profileVCProfileImage.image = photo
                    lbl_profileVCname.text = name
                }
            }
        }
        
        sqlite3_finalize(statement)
    }
   
    func fetchCollectionViewData(for userId: Int) {
        let query = "SELECT * FROM UserData WHERE userId = ?;"
        var statement: OpaquePointer?
        userData.removeAll()

        if sqlite3_prepare(db, query, -1, &statement, nil) == SQLITE_OK {
            // Bind the user ID parameter to the statement
            if sqlite3_bind_int(statement, 1, Int32(userId)) != SQLITE_OK {
                print("Error binding userId")
                return
            }
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let dataId = sqlite3_column_int(statement, 0)
                let location = String(cString: sqlite3_column_text(statement, 2))
                let description = String(cString: sqlite3_column_text(statement, 3))
                
                let photoData = Data(bytes: sqlite3_column_blob(statement, 4), count: Int(sqlite3_column_bytes(statement, 4)))
                let photo = UIImage(data: photoData)
                
                print("DataId: \(dataId), Location: \(location), Description: \(description)")
                
                userData.append((Int(dataId), location, description, photo))
            }
        } else {
            print("Error reading data")
        }
        
        sqlite3_finalize(statement)
        
        collectionView.reloadData()
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
           return userData.count
       }

       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfileVCCollectionViewCell", for: indexPath) as! ProfilePageCollectionViewCell
           
           let data = userData[indexPath.row]
           cell.ProfilePageCollectionViewimageView.image = data.photo
           
           return cell
       }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedData = userData[indexPath.row]
        let selectedDocumentID = selectedData.dataId
        print("Selected Document ID: \(selectedDocumentID)")
        if let imageDetailVC = storyboard?.instantiateViewController(withIdentifier: "PostEditPageVC") as? EditPostDataViewController {

            imageDetailVC.selectedID = selectedDocumentID
            imageDetailVC.db = self.db
         
            navigationController?.pushViewController(imageDetailVC, animated: true)

    }
    }
    
}
extension UIStackView {
    func removeAllArrangedSubviews() {
        arrangedSubviews.forEach { $0.removeFromSuperview() }
    }
}

