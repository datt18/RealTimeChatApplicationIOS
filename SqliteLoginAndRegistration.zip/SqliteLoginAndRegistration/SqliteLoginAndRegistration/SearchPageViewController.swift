//
//  SearchPageViewController.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 15/03/24.
//

import UIKit
import SQLite3
class SearchPageViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    @IBOutlet weak var SearchtableView: UITableView!
    @IBOutlet weak var SearchPagenameTextField: UITextField!
    var db: OpaquePointer?

    var names: [String] = []
    var filteredNames: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        openDatabase()
        fetchUsernames()
        SearchPagenameTextField.delegate = self
        SearchtableView.dataSource = self
        SearchtableView.delegate = self
        SearchPagenameTextField.layer.borderColor = UIColor.black.cgColor
        SearchPagenameTextField.layer.borderWidth = 1.0
        SearchPagenameTextField.layer.cornerRadius = 10.0
        SearchPagenameTextField.layer.borderColor = UIColor.lightGray.cgColor
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        openDatabase()
        fetchUsernames()
        let searchIcon = UIImageView(image: UIImage(systemName: "magnifyingglass"))
        searchIcon.tintColor = .systemGray
        SearchPagenameTextField.rightView = searchIcon
        SearchPagenameTextField.rightViewMode = .always
    }
    func openDatabase() {
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
               .appendingPathComponent("users.sqlite")
           if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
               print("Error opening database")
               return
           }
       }
    func fetchUsernames() {
           let query = "SELECT username FROM users;"
           var statement: OpaquePointer?
        names.removeAll()

           if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
               while sqlite3_step(statement) == SQLITE_ROW {
                   if let usernamePtr = sqlite3_column_text(statement, 0) {
                       let username = String(cString: usernamePtr)
                       names.append(username)
                   }
               }
               filteredNames = names
               SearchtableView.reloadData()
           } else {
               print("Error fetching usernames")
           }
           
           sqlite3_finalize(statement)
       }
  
       
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var newText = (textField.text ?? "") as NSString
        newText = newText.replacingCharacters(in: range, with: string) as NSString
                if newText.length == 0 {
                    fetchUsernames()
                SearchtableView.reloadData()
                    let searchIcon = UIImageView(image: UIImage(systemName: "magnifyingglass"))
                    searchIcon.tintColor = .systemGray
                    SearchPagenameTextField.rightView = searchIcon
                    SearchPagenameTextField.rightViewMode = .always
                    
        } else {
            filterNames(with: newText as String)
            SearchtableView.reloadData()
            let clearButton = UIButton(type: .custom)
            clearButton.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
            clearButton.tintColor = .systemGray
            clearButton.addTarget(self, action: #selector(clearSearchText), for: .touchUpInside)
            SearchPagenameTextField.rightView = clearButton
            SearchPagenameTextField.rightViewMode = .always
        }
        
        return true
    }

    func filterNames(with searchText: String) {
        if searchText.isEmpty {
            filteredNames = names
           
      
        } else {
            filteredNames = names.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
     
        SearchtableView.reloadData()
    }
   
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
           print("TextField should begin editing method called")
           return true;
       }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return filteredNames.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchTableCell", for: indexPath) as? HomePageTableViewCell
           cell?.backgroundColor = UIColor.white
           cell?.layer.borderColor = UIColor.lightGray.cgColor
    cell?.layer.borderWidth = 0.4
                      
            cell?.SearchPageUsernameLabel.text = filteredNames[indexPath.row]
        return cell!
    }
   


       

    @objc func clearSearchText() {
        SearchPagenameTextField.text = ""
        filterNames(with: "")
        SearchtableView.reloadData()
        let searchIcon = UIImageView(image: UIImage(systemName: "magnifyingglass"))
        searchIcon.tintColor = .systemGray
        SearchPagenameTextField.rightView = searchIcon
        SearchPagenameTextField.rightViewMode = .always

    }

}
