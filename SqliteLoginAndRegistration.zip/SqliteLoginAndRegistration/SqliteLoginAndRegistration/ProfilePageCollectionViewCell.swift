//
//  ProfilePageCollectionViewCell.swift
//  SqliteLoginAndRegistration
//
//  Created by elsner on 18/03/24.
//

import UIKit
      
class ProfilePageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var ProfilePageCollectionViewimageView: UIImageView!
}
