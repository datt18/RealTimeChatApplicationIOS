//
//  modulefile.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 07/03/24.
//

import Foundation
import Firebase
import FirebaseDatabase
import FirebaseFirestore
class User {
       var name: String
    var id: String
       // Add other properties as needed

    init(name: String,id: String) {
           self.name = name
        self.id = id
       }
   }

class profiledata {
    var profilename: String
    var profileUsername: String
    // Add other properties as needed

    init(profilename:String, profileUsername: String) {
        self.profilename = profilename
        self.profileUsername = profileUsername
    }

}
class AfterSearchdata {
    var AfterSearchname: String
    var AfterSearchUsername: String
    // Add other properties as needed

    init(AfterSearchname:String, AfterSearchUsername: String) {
        self.AfterSearchname = AfterSearchname
        self.AfterSearchUsername = AfterSearchUsername
    }

}
class Editdata {
    var editname: String
    var editUsername: String
    var editemail : String
    // Add other properties as needed

    init(editname:String, editUsername: String, editemail: String) {
        self.editname = editname
        self.editUsername = editUsername
        self.editemail = editemail
    }

}
struct YourDataModel {
    var editname: String
    var editUsername: String
    var editemail: String
    // Add other properties as needed
}


//class CollectionviewData {
//
//    var collectionviewIamge: String
//
//    init(collectionviewIamge: String) {
//
//        self.collectionviewIamge = collectionviewIamge
//    }
//
//}

