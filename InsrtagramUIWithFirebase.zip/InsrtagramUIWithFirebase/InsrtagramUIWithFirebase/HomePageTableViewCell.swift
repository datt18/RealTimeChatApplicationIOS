//
//  HomePageTableViewCell.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit

class HomePageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lbl_usernameHomePage: UILabel!
    @IBOutlet weak var lbl_AddressHomePage: UILabel!
    @IBOutlet weak var lbl_Description: UILabel!
    @IBOutlet weak var img_ImageHomePage: UIImageView!
    @IBOutlet weak var img_iconImageHomePage: UIImageView!



    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

              // Register the collection view cell
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
