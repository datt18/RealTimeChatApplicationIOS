//
//  RegistrationViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class RegistrationViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    
   
    @IBOutlet weak var emailTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var UserNameTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var nameTextFieldRegistrationPage: UITextField!
    @IBOutlet weak var PasswordFieldRegistrationPage: UITextField!
    @IBOutlet weak var btn_registrationRegistrationPage: UIButton!
    @IBOutlet weak var lbl_LoginRegistrationPage: UILabel!
    @IBOutlet weak var btn_ProfilePhotoUploadRegVC: UIButton!
    @IBOutlet weak var Img_ProfilePhotoSelectedRegVC: UIImageView!

    let imagePicker = UIImagePickerController()


    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self

        btn_registrationRegistrationPage.layer.cornerRadius = 10
        btn_registrationRegistrationPage.layer.masksToBounds = true
        
        let attributedString = NSMutableAttributedString(string: "have an Account? Log In!")
        let termsRange = (attributedString.string as NSString).range(of: "Log In!")
        attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 17), range: termsRange)
        lbl_LoginRegistrationPage.attributedText = attributedString
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped1))
        lbl_LoginRegistrationPage.isUserInteractionEnabled = true
        lbl_LoginRegistrationPage.addGestureRecognizer(tapGesture)

    }
    @IBAction func chooseProfilePhoto(_ sender: UIButton) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            Img_ProfilePhotoSelectedRegVC.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
 
    @objc func labelTapped1(sender: UITapGestureRecognizer) {
        print("click")
        let secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "LoginVC") as! ViewController
        self.navigationController!.pushViewController(secondViewController, animated: true)
        
    }
    @IBAction func registerButtonTapped(_ sender: UIButton) {
        guard let email = emailTextFieldRegistrationPage.text, !email.isEmpty else {
            showAlert(message: "Please enter a valid email address.")
            return
        }
        guard let username = UserNameTextFieldRegistrationPage.text, !username.isEmpty else {
            showAlert(message: "Please enter a valid username.")
            return
        }
        guard let name = nameTextFieldRegistrationPage.text, !name.isEmpty else {
            showAlert(message: "Please enter your name.")
            return
        }
       
        guard let password = PasswordFieldRegistrationPage.text, password.count >= 8 else {
            showAlert(message: "Password is InValid")
            return
        }
        guard let image = Img_ProfilePhotoSelectedRegVC.image else {
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { [weak self] authResult, error in
            guard let self = self else { return }
            
            if let error = error {
                print("Error registering user: \(error.localizedDescription)")
                self.showAlert(message: "Registration failed. Please try again.")
            } else if let uid = authResult?.user.uid {
                // User registered successfully, now store additional information in Firebase Realtime Database
                let userReference = Database.database().reference().child("users").child(uid)
                let userData = ["name": name, "email": email, "username": username, "regUserId": uid]

                
                userReference.setValue(userData) { (error, ref) in
                    if let error = error {
                        print("Error storing user data: \(error.localizedDescription)")
//                        self.showAlert(message: "Registration failed. Please try again.")
                    } else {
                        print("User data stored successfully")
                        self.showAlert(message: "Registration successfully Done!.")
                        
                    }
                }
            }
        }
    }
    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == nameTextFieldRegistrationPage {
            let allowedCharacters = CharacterSet(charactersIn:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")
                   let characterSet = CharacterSet(charactersIn: string)
                   return allowedCharacters.isSuperset(of: characterSet)
        }
        return true
    }
}



//extension String {
////    func isValidMobileNumber() -> Bool {
////        let mobileRegex = "^[0-9]{10}$"
////        return NSPredicate(format: "SELF MATCHES %@", mobileRegex).evaluate(with: self)
////    }
//    func isValidPassword() -> Bool {
//        let reqularExpression = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
//        return NSPredicate(format: "SELF MATCHES %@", reqularExpression).evaluate(with: self)
//    }
//    func isValidEmail() -> Bool {
//            let emailRegex = "[0-9a-z._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}"
//            return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: self)
//        }
//

