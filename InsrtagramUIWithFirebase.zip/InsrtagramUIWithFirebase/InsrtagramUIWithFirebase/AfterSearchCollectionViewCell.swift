//
//  AfterSearchCollectionViewCell.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 08/03/24.
//

import UIKit

class AfterSearchCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img_ImageCollectionViewAfterSearchVC: UIImageView!

}
