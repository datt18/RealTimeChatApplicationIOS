//
//  HomePageCollectionViewCell.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit

class HomePageCollectionViewCell: UICollectionViewCell {
    
}
