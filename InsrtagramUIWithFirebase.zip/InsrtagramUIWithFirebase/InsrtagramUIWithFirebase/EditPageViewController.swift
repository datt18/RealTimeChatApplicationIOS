//
//  EditPageViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 08/03/24.
//

import UIKit
import FirebaseFirestore
import Firebase

class EditPageViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var EditemailTextField: UITextField!
    @IBOutlet weak var EditusernameTextField: UITextField!
    @IBOutlet weak var EditnameTextField: UITextField!
    @IBOutlet weak var btn_ProfilePhotoUpload: UIButton!
    @IBOutlet weak var Img_ProfilePhotoSelected: UIImageView!
    let imagePicker = UIImagePickerController()
    
    
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        
        Img_ProfilePhotoSelected.layer.cornerRadius = Img_ProfilePhotoSelected.frame.height/2
        Img_ProfilePhotoSelected.layer.masksToBounds = true

        loadUserData1()
        //        fetchDataFromFirebase { (data) in
        //        }
        Img_ProfilePhotoSelected.layer.cornerRadius = Img_ProfilePhotoSelected.frame.height/2
        Img_ProfilePhotoSelected.layer.masksToBounds = true
        
    }
    @IBAction func chooseProfilePhoto(_ sender: UIButton) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            Img_ProfilePhotoSelected.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    
    func loadUserData1() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let userReference = Database.database().reference().child("users").child(uid)
        
        userReference.observeSingleEvent(of: .value) { snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let email = userData["email"] as? String,
                  let name = userData["name"] as? String,
                  let username = userData["username"] as? String else {
                return
            }
            let currentUserData = Editdata(editname: name, editUsername: username, editemail: email)
            self.updateUI(with: currentUserData)
        }
    }
    func updateUI(with data: Editdata) {
        // Update your UI elements with the fetched data
        EditemailTextField.text = data.editemail
        EditusernameTextField.text = data.editUsername
        EditnameTextField.text = data.editname
    }
    func FatchDataUpdate(){
        guard let edituid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let ref = Database.database().reference().child("users").child(edituid)
        
        let updatedData = [
            "name": EditnameTextField.text ?? "",
            "email": EditemailTextField.text ?? "",
            "username": EditusernameTextField.text ?? ""
            
        ]
        ref.updateChildValues(updatedData) { error,ref  in
            if let error = error {
                print("Error Editing document: \(error)")
            } else {
                print("Document Edit successfully!")
                self.navigationController?.popViewController(animated: true)

            }
        }
    }
    
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        FatchDataUpdate()
        //        guard let image = Img_ProfilePhotoSelected.image,
        //              let imageData = image.jpegData(compressionQuality: 0.5) else {
        //            return
        //              }
        //        saveDataToFirebase(imageData: imageData)
        
    }
    
//    func saveDataToFirebase(imageData: Data) {
        //        let databaseRef = Database.database().reference()
        //        let currentUser = Auth.auth().currentUser
        //
        //        guard let userId = currentUser?.uid else {
        //            // Handle the case where the user is not logged in
        //            return
        //        }
        //
        //        let photosRef = databaseRef.child("users").child(userId)
        //
        //        let photoData: [String: Any] = [
        //            "ProfileimageData": imageData.base64EncodedString(),
        //        ]
        //
        //        photosRef.setValue(photoData) { (error, _) in
        //            if let error = error {
        //                print("Error saving data to Firebase: \(error)")
        //            } else {
        //                print("Data saved successfully!")
        //            }
        //        }
        //    }
        
//    }
    
}


