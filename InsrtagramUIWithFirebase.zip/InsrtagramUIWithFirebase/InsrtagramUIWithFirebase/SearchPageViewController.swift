//
//  SearchPageViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit
import Firebase
class SearchPageViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate  {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    //    var data = ["Apple", "Banana", "Cherry", "Date", "Grape", "Kiwi", "Lemon", "Mango", "Orange", "Peach"]
    //    var filteredData: [String] = []
    var users: [User] = []
    var filteredUsers: [User] = []
    
    let refreshControl = UIRefreshControl()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()

        searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        loadDataFromFirebase()
        tableView.reloadData()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refreshSearch(_:)), for: .valueChanged)
        tableView.addSubview(refreshControl)
        
        filteredUsers = users
    }
    @objc func refreshSearch(_ sender: AnyObject) {
        self.loadDataFromFirebase()
    }
    func loadDataFromFirebase() {
       
        
        let userReference = Database.database().reference().child("users")
        
        userReference.observe(.value) { [weak self] snapshot in
            guard let self = self else { return }
            
            for child in snapshot.children {
                if let childSnapshot = child as? DataSnapshot,
                   let userData = childSnapshot.value as? [String: Any],
                   let userId = userData["regUserId"] as? String,
                   let userName = userData["username"] as? String {
                    let user = User(name: userName, id: userId)
                    self.users.append(user)
                    print("users", user)
                }
            }
            
            self.tableView.reloadData()
        }
    }
    //
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        filteredUsers = searchText.isEmpty ? users : users.filter { $0.name.lowercased().contains(searchText.lowercased()) }
//        tableView.reloadData()
//    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredUsers = searchText.isEmpty ? users : users.filter { user in
            let nameContains = user.name.lowercased().contains(searchText.lowercased())
            let idContains = user.id.lowercased().contains(searchText.lowercased())
            return nameContains
        }
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchPageCell", for: indexPath) as! SearchPageTableViewCell
        //        let user = filteredUsers[indexPath.row]
        //        cell.lbl_searchData.text = user.name
        if indexPath.row < filteredUsers.count {
            let user = filteredUsers[indexPath.row]
            cell.lbl_searchData.text =  user.name
        } else {
            cell.lbl_searchData.text = ""
        }


        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let destinationVC = storyboard.instantiateViewController(withIdentifier: "AfterSearchDataVC") as? AfterSearchViewController {
            let doc = filteredUsers[indexPath.row]
            destinationVC.selectedUserID = doc.id
    
                navigationController?.pushViewController(destinationVC, animated: true)
            
        }
        
        
    }
}
