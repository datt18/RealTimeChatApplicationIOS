//
//  SearchPageTableViewCell.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit

class SearchPageTableViewCell: UITableViewCell {
    @IBOutlet weak var lbl_searchData: UILabel!
    let refreshControl = UIRefreshControl()

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
