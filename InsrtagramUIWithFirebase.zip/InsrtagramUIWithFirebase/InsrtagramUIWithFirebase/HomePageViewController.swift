//
//  HomePageViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class HomePageViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    let refreshControl = UIRefreshControl()

    var data: [DocumentSnapshot] = []
    let db = Firestore.firestore()
    var photosData: [(username: String, address: String,description: String, image: UIImage)] = [] 

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
            tableView.delegate = self
//        fetchData()
        fetchPhotosData()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
           refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
           tableView.addSubview(refreshControl)
        tableView.reloadData()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
        self.fetchPhotosData()

    }
    @objc func refresh(_ sender: AnyObject) {
//        self.fetchData()
        self.tableView.reloadData()
    }
    @IBAction func btn_adddataAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondViewController = storyboard.instantiateViewController(withIdentifier: "PostPageVC") as! AddDataPageViewController
        self.navigationController!.pushViewController(secondViewController, animated: true)
    
//        let alertController = UIAlertController(title: "Add Data", message: nil, preferredStyle: .alert)

//        alertController.addTextField { textField in
//            textField.placeholder = "Name"
//        }
//        alertController.addTextField { textField in
//            textField.placeholder = "Description"
//        }
//        alertController.addTextField { textField in
//            textField.placeholder = "Location"
//        }
//        alertController.addTextField { textField in
//            textField.placeholder = "imageUrl"
//        }
//
//        let addAction = UIAlertAction(title: "Add", style: .default) { [weak self] _ in
//            guard let name = alertController.textFields?[0].text,
//                  let description = alertController.textFields?[1].text,
//                   let Location = alertController.textFields?[2].text,
//                  let imageUrl = alertController.textFields?[3].text else {
//                return
//            }
//            guard let currentUser = Auth.auth().currentUser else {
//                        // Handle the case when there is no authenticated user
//                        return
//                    }
//
//
//            // Add data to Firestore
//            let db = Firestore.firestore()
//           let newdata = db.collection("yourCollectionNameHomePage").addDocument(data: [
//                "name": name,
//                "description": description,
//                "Location": Location,
//                "imageUrl": imageUrl,
//                "userId": currentUser.uid
//           ]) { error in
//                if let error = error {
//                    print("Error adding document: \(error)")
//                } else {
//                    print("Data added successfully")
//                //    data.sort { $0.name < $1.name }
//                    self!.fetchData()
//
//                }
//            }
//        }
//
//        alertController.addAction(addAction)
//        present(alertController, animated: true, completion: nil)

    }
//    func fetchData() {
//           db.collection("yourCollectionNameHomePage").getDocuments { [weak self] (querySnapshot, error) in
//               guard let self = self, let documents = querySnapshot?.documents else {
//                   print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
//                   return
//               }
//
//               self.data = documents
//               self.tableView.reloadData()
//           }
//       }
    @IBAction func btn_EditPostData(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondViewController = storyboard.instantiateViewController(withIdentifier: "PostEditPageVC") as! HomePostEditViewController
        self.navigationController!.pushViewController(secondViewController, animated: true)
    }

    func fetchPhotosData() {
        let db = Firestore.firestore()
        let photosCollection = db.collection("your_collectionPost")

        photosCollection.getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching documents: \(error)")
                return
            }

            guard let snapshot = snapshot else {
                print("No documents found")
                return
            }

            self.photosData.removeAll()

            for document in snapshot.documents {
                if let imageData = document.data()["imageData"] as? Data,
                   let image = UIImage(data: imageData),
                   let username = document.data()["username"] as? String,
                   let description = document.data()["description"] as? String,
                   let address = document.data()["address"] as? String {
                    let photoData = (username: username, address: address,description: description, image: image)
                    self.photosData.append(photoData)
                }
            }

            self.tableView.reloadData()
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return photosData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomePageTablecell", for: indexPath) as! HomePageTableViewCell
        let photoData = photosData[indexPath.row]
        cell.img_ImageHomePage.image = photoData.image
        cell.img_iconImageHomePage.image = photoData.image
        cell.lbl_Description.text = photoData.description
        cell.lbl_usernameHomePage.text = photoData.username
        cell.lbl_AddressHomePage.text = photoData.address
        cell.img_iconImageHomePage.layer.cornerRadius = cell.img_iconImageHomePage.frame.height/2
        cell.img_iconImageHomePage.layer.masksToBounds = true
        cell.layer.masksToBounds = true
//        cell.layer.cornerRadius = 0
        cell.layer.borderWidth = 0.5
        cell.layer.borderColor = UIColor(red:196/255, green:196/255, blue:196/255, alpha: 1).cgColor
        
        return cell
    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("task is pass data")
//        let secondVC = storyboard?.instantiateViewController(withIdentifier: "DeatilsVC") as! DetailsOfdataViewController
//        let doc = data[indexPath.row].documentID
//        secondVC.documentID = doc
//        navigationController?.pushViewController(secondVC, animated: true)
//    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 390

    }
    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
}
    


