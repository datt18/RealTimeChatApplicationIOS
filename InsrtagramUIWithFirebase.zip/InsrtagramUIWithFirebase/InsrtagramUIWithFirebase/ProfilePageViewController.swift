//
//  ProfilePageViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 07/03/24.
//

import UIKit
import FirebaseAuth
import Firebase
import SDWebImage

class ProfilePageViewController: UIViewController,  UICollectionViewDataSource, UICollectionViewDelegate{
    @IBOutlet weak var collectionViewProfilePage: UICollectionView!
    
    
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    var profiledatas: [profiledata] = []
    var profilepageCollectionviewData:  [(image: UIImage, documentID: String)] = []
//    var lbl_items = ["e6","cat1","tiger1"]
  
   var EdituserId = Auth.auth().currentUser?.uid
    @IBOutlet weak var usernameProfilePage: UILabel!
    @IBOutlet weak var nameProfilePage: UILabel!
    @IBOutlet weak var img_ProfileImageProfilePage: UIImageView!

    @IBOutlet weak var dropdownButton: UIButton!

//    let dropdownButton: UIButton = {
//        let button = UIButton()
//        let dropdownImage = UIImage(systemName: "arrow.down.circle.fill")
//        button.setTitle("...", for: .normal)
//        button.setTitleColor(.blue, for: .normal)
//        button.addTarget(self, action: #selector(dropdownButtonTapped), for: .touchUpInside)
//        return button
//    }()
    

    let dropdownMenu: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.isHidden = true
        stackView.backgroundColor = .white
        return stackView
    }()

    let blurEffectView: UIVisualEffectView = {
           let blurEffect = UIBlurEffect(style: .light)
           let blurEffectView = UIVisualEffectView(effect: blurEffect)
           blurEffectView.alpha = 0.4
           return blurEffectView
       }()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(dropdownButton)
        view.addSubview(blurEffectView)
        blurEffectView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.8)
        blurEffectView.isHidden = true
        view.addSubview(dropdownMenu)
        setupConstraints()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
               view.addGestureRecognizer(tapGestureRecognizer)

        firebasedata()
        fetchCurrentUserPhotosData()
        collectionViewProfilePage.reloadData()

        collectionViewProfilePage.delegate = self
        collectionViewProfilePage.dataSource = self
        screenSize = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: screenWidth/3, height: screenHeight/6)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 1
        collectionViewProfilePage!.collectionViewLayout = layout
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.firebasedata()
        self.fetchCurrentUserPhotosData()
        collectionViewProfilePage.reloadData()
    }
    func setupConstraints() {
        dropdownButton.translatesAutoresizingMaskIntoConstraints = false
        dropdownMenu.translatesAutoresizingMaskIntoConstraints = false
        blurEffectView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            dropdownButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: -20),
            dropdownButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0),

            dropdownMenu.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            dropdownMenu.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -3),
            blurEffectView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurEffectView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            dropdownMenu.widthAnchor.constraint(equalToConstant: 120),
            dropdownMenu.heightAnchor.constraint(equalToConstant: 80),
            blurEffectView.topAnchor.constraint(equalTo: view.topAnchor),
            blurEffectView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
          

        ])
//        NSLayoutConstraint.activate([
//                  blurEffectView.topAnchor.constraint(equalTo: view.topAnchor),
//                  blurEffectView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//                  blurEffectView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//                  blurEffectView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//              ])

        
    }
    
    @IBAction func dropdownButtonTapped(_ sender: Any) {
        print("click btn")
//        dropdownMenu.isHidden.toggle()
//        updateDropdownMenu()
//        blurEffectView.isHidden = !dropdownMenu.isHidden
        UIView.animate(withDuration: 0.3) {
            self.blurEffectView.isHidden = !self.dropdownMenu.isHidden
                   self.dropdownMenu.isHidden.toggle()
                   self.updateDropdownMenu()
               }
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
          let location = sender.location(in: collectionViewProfilePage)
        if !dropdownMenu.isHidden {
            UIView.animate(withDuration: 0.3) {
                self.dropdownMenu.isHidden = true
                self.blurEffectView.isHidden = true
            }
        } else {

          if let indexPath = collectionViewProfilePage.indexPathForItem(at: location) {
              let selectedData = profilepageCollectionviewData[indexPath.row]
              let selectedDocumentID = selectedData.documentID
              print("Selected Document ID: \(selectedDocumentID)")
              let storyboard = UIStoryboard(name: "Main", bundle: nil)
              if let imageDetailVC = storyboard.instantiateViewController(withIdentifier: "PostEditPageVC") as? HomePostEditViewController {
                  imageDetailVC.selectedDocumentID = selectedDocumentID
                  navigationController?.pushViewController(imageDetailVC, animated: true)
              }
          }
          }
      }

//    @objc func handleTap(_ sender: UITapGestureRecognizer) {
//            if !dropdownMenu.isHidden {
//                UIView.animate(withDuration: 0.3) {
//                    self.dropdownMenu.isHidden = true
//                    self.blurEffectView.isHidden = true
//                }
//            }
//        }

    func updateDropdownMenu() {
        dropdownMenu.removeAllArrangedSubviews()
        let editButton = UIButton()
        editButton.setTitle("Edit Profile", for: .normal)
        editButton.setTitleColor(.black, for: .normal)
        editButton.addTarget(self, action: #selector(editButtonTapped), for: .touchUpInside)
        let logoutButton = UIButton()
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.setTitleColor(.black, for: .normal)
        logoutButton.addTarget(self, action: #selector(logoutButtonTapped), for: .touchUpInside)

//        logoutButton.setContentHuggingPriority(.required, for: .horizontal)
//        logoutButton.setContentCompressionResistancePriority(.required, for: .horizontal)

        dropdownMenu.addArrangedSubview(editButton)
        dropdownMenu.addArrangedSubview(logoutButton)
    }

    @objc func editButtonTapped() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let destinationVC = storyboard.instantiateViewController(withIdentifier: "Editpage") as? EditPageViewController {
                self.navigationController?.pushViewController(destinationVC, animated: true)
            }
            print("Edit button tapped")
        }
    @objc func logoutButtonTapped() {
        let confirmLogoutAlert = UIAlertController(title: "Confirm Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)

        let cancelConfirmationAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        confirmLogoutAlert.addAction(cancelConfirmationAction)

        let confirmAction = UIAlertAction(title: "Yes", style: .default) { _ in
                    do {
                        try Auth.auth().signOut()
                        if let loginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as? ViewController {
                            self.navigationController?.pushViewController(loginViewController, animated: true)
                        }

                    } catch let signOutError as NSError {
                        print("Error signing out: \(signOutError.localizedDescription)")
                    }

        }
        confirmLogoutAlert.addAction(confirmAction)
        self.present(confirmLogoutAlert, animated: true, completion: nil)
        print("Logout button tapped")
    }

   
    
    func fetchCurrentUserPhotosData() {
        guard let currentUser = Auth.auth().currentUser else {
            return
        }

        let db = Firestore.firestore()
        let photosCollection = db.collection("your_collectionPost")

        photosCollection.whereField("UserID", isEqualTo: currentUser.uid).getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching documents: \(error)")
                return
            }

            guard let snapshot = snapshot else {
                print("No documents found")
                return
            }

            self.profilepageCollectionviewData.removeAll()

            for document in snapshot.documents {
                if let imageData = document.data()["imageData"] as? Data,
                   let image = UIImage(data: imageData),
                   let documentID = document.documentID as? String {
                    self.profilepageCollectionviewData.append((image: image, documentID: documentID))

                }
            }

            self.collectionViewProfilePage.reloadData()
        }
    }
    func firebasedata() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let userReference = Database.database().reference().child("users").child(uid)
        
        userReference.observeSingleEvent(of: .value) { snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let name = userData["name"] as? String,
                  let username = userData["username"] as? String else {
                return
            }
            let currentUserData = profiledata(profilename: name, profileUsername: username)
            self.updateUI(with: currentUserData)
        }
    }
    
    func updateUI(with data: profiledata) {
        usernameProfilePage.text = data.profileUsername
        nameProfilePage.text = data.profilename
    }
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return profilepageCollectionviewData.count
//        return lbl_items.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        var data:String = lbl_items[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfilePageCollectionViewCell", for: indexPath as IndexPath) as! ProfilePageCollectionViewCell
        cell.img_ImageCollectionViewParofilePage.image = profilepageCollectionviewData[indexPath.row].image

//        cell.backgroundColor = UIColor(red: 255/255, green: 214/255, blue: 211/255, alpha: 1)
//        cell.layer.borderWidth = 0.5
//        cell.layer.borderColor = UIColor.black.cgColor
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedData = profilepageCollectionviewData[indexPath.row]
        let selectedImage = selectedData.image
        let selectedDocumentID = selectedData.documentID
            print("Selected Document ID: \(selectedDocumentID)")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let imageDetailVC = storyboard.instantiateViewController(withIdentifier: "PostEditPageVC") as? HomePostEditViewController {
//                imageDetailVC.selectedImage = selectedImage
                imageDetailVC.selectedDocumentID = selectedDocumentID
                navigationController?.pushViewController(imageDetailVC, animated: true)

        }
    }

}
extension UIStackView {
    func removeAllArrangedSubviews() {
        arrangedSubviews.forEach { $0.removeFromSuperview() }
    }
}
