//
//  AfterSearchViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 08/03/24.
//

import UIKit
import FirebaseAuth
import Firebase
import SDWebImage

class AfterSearchViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    @IBOutlet weak var collectionViewAfterSearchVC: UICollectionView!
    @IBOutlet weak var usernameAfterSearchVC: UILabel!
    @IBOutlet weak var nameAfterSearchVC: UILabel!
    @IBOutlet weak var img_ProfileImageAfterSearchVC: UIImageView!
    @IBOutlet weak var btn_FollowingAfterSearchPage: UIButton!
    @IBOutlet weak var btn_messageAfterSearchPage: UIButton!

    
     var screenSize: CGRect!
        var screenWidth: CGFloat!
        var screenHeight: CGFloat!
    var selectedUserID: String?
//    var lbl_items = ["e6","cat1","tiger1"]
    var AfterSearchCollectionviewData: [UIImage] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        btn_FollowingAfterSearchPage.layer.cornerRadius = 10
        btn_FollowingAfterSearchPage.layer.masksToBounds = true
        btn_messageAfterSearchPage.layer.cornerRadius = 10
        btn_messageAfterSearchPage.layer.masksToBounds = true
        collectionViewAfterSearchVC.delegate = self
        collectionViewAfterSearchVC.dataSource = self
        screenSize = UIScreen.main.bounds
              screenWidth = screenSize.width
              screenHeight = screenSize.height
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
               layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
               layout.itemSize = CGSize(width: screenWidth/3, height: screenHeight/6)
               layout.minimumInteritemSpacing = 0
               layout.minimumLineSpacing = 1
        
        collectionViewAfterSearchVC!.collectionViewLayout = layout
        AftresearchData()
        CollectionViewDataFatchfromFirebase()
    }
    func CollectionViewDataFatchfromFirebase() {
    

        let db = Firestore.firestore()
        let photosCollection = db.collection("your_collectionPost") // Replace with your actual collection name

        photosCollection.whereField("UserID", isEqualTo: selectedUserID).getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching documents: \(error)")
                return
            }

            guard let snapshot = snapshot else {
                print("No documents found")
                return
            }

            self.AfterSearchCollectionviewData.removeAll()

            for document in snapshot.documents {
                if let imageData = document.data()["imageData"] as? Data,
                   let image = UIImage(data: imageData){
                    self.AfterSearchCollectionviewData.append(image)
                }
            }

            self.collectionViewAfterSearchVC.reloadData()
        }

    }
    func AftresearchData() {
        print(selectedUserID)

        let userReference = Database.database().reference().child("users").child(selectedUserID!)
        userReference.observeSingleEvent(of: .value) { snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let name = userData["name"] as? String,
                  let username = userData["username"] as? String else {
                return
            }
            let currentUserData = AfterSearchdata(AfterSearchname: name, AfterSearchUsername: username)
            self.updateUI(with: currentUserData)
        }
    }
    
    func updateUI(with data: AfterSearchdata) {
        // Update your UI elements with the fetched data
        usernameAfterSearchVC.text = data.AfterSearchname
        nameAfterSearchVC.text = data.AfterSearchUsername
    }
    
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AfterSearchCollectionviewData.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AfterSearchVCCell", for: indexPath as IndexPath) as! AfterSearchCollectionViewCell
        cell.img_ImageCollectionViewAfterSearchVC.image = AfterSearchCollectionviewData[indexPath.row]

            return cell
    }
    

}
