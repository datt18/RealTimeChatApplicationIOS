//
//  AddDataPageViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 06/03/24.
//

import UIKit
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase
import Firebase
class AddDataPageViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var UsernameTextField: UITextField!
    @IBOutlet weak var AddressTextField: UITextField!
    @IBOutlet weak var DescriptinTextField: UITextField!
    @IBOutlet weak var PostButton: UIButton!
    @IBOutlet weak var photoButton: UIButton!
    @IBOutlet weak var img_selectedphoto: UIImageView!
    let imagePicker = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        
        img_selectedphoto.layer.cornerRadius = img_selectedphoto.frame.height/2
        img_selectedphoto.layer.masksToBounds = true
    }
    
    @IBAction func choosePhotoButtonTapped(_ sender: UIButton) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            img_selectedphoto.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveDataButtonTapped(_ sender: UIButton) {
        guard let username = UsernameTextField.text,
              let description = DescriptinTextField.text,
              let address = AddressTextField.text,
              let image = img_selectedphoto.image else {
            return
        }
        
        let imageData = image.jpegData(compressionQuality: 0.5) // Adjust compression quality as needed
        
        let db = Firestore.firestore()
        let photosCollection = db.collection("your_collectionPost")
        guard let currentUser = Auth.auth().currentUser else {
            return
        }
        
        let documentData: [String: Any] = [
            "imageData": imageData as Any,
            "username" : username as Any,
            "description": description,
            "address": address,
            "UserID" : currentUser.uid
        ]
        
        
        photosCollection.addDocument(data: documentData) { error in
            if let error = error {
                print("Error adding document: \(error)")
            } else {
//                print("Document added successfully!")
                self.navigationController?.popViewController(animated: true)
                self.showAlert12(message: "Post is successfully upload!.")

            }
        }
        
    }
    func showAlert12(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}


