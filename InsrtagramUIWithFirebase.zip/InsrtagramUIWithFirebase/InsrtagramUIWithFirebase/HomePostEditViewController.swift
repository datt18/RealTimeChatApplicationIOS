//
//  HomePostEditViewController.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 12/03/24.
//

import UIKit
import FirebaseAuth
import Firebase
import SDWebImage
class HomePostEditViewController: UIViewController, UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
    @IBOutlet weak var PostEditUsernametextField: UITextField!
    @IBOutlet weak var PostEditAddresstextField: UITextField!
    @IBOutlet weak var PostEditDescriptiontextField: UITextField!
    @IBOutlet weak var btn_EditPost: UIButton!
    @IBOutlet weak var Img_EditPostImg: UIImageView!
    let imagePicker = UIImagePickerController()
    var selectedDocumentID: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDataForDocumentID()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchDataForDocumentID()
    }
    
    
    @IBAction func EditPhotoUpload(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let editedImage = info[.editedImage] as? UIImage {
            Img_EditPostImg.image = editedImage
        } else if let originalImage = info[.originalImage] as? UIImage {
            Img_EditPostImg.image = originalImage
        }

        dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }


    func fetchDataForDocumentID() {
        guard let documentID = selectedDocumentID else {
            return
        }

        let db = Firestore.firestore()
        let documentReference = db.collection("your_collectionPost").document(documentID)

        documentReference.getDocument { (document, error) in
            if let error = error {
                print("Error fetching document: \(error)")
                return
            }

            guard let document = document, document.exists else {
                print("Document does not exist")
                return
            }

            // Extract data from the document
            if let imageData = document.data()?["imageData"] as? Data,
               let image = UIImage(data: imageData),
               let username = document.data()?["username"] as? String,
               let address = document.data()?["address"] as? String,
               let description = document.data()?["description"] as? String {
                // Update UI elements with the fetched data
                self.Img_EditPostImg.image = image
                self.PostEditUsernametextField.text = username
                self.PostEditAddresstextField.text = address
                self.PostEditDescriptiontextField.text = description
            }
        }
    }
    
    @IBAction func saveEditPostTapped(_ sender: Any) {
        guard let documentID = selectedDocumentID else {
            return
        }
        let db = Firestore.firestore()
        let documentReference = db.collection("your_collectionPost").document(documentID)

        let updatedData: [String: Any] = [
            "imageData": Img_EditPostImg.image?.jpegData(compressionQuality: 0.5) as Any,
            "username": PostEditUsernametextField.text ?? "",
            "address": PostEditAddresstextField.text ?? "",
            "description": PostEditDescriptiontextField.text ?? ""
            // Add other fields as needed
        ]

        documentReference.updateData(updatedData) { error in
            if let error = error {
                print("Error updating document: \(error)")
            } else {
                print("Document successfully updated!")
                self.navigationController?.popViewController(animated: true)

            }
        }
    }


}
