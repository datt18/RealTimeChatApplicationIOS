//
//  ProfilePageCollectionViewCell.swift
//  InsrtagramUIWithFirebase
//
//  Created by elsner on 07/03/24.
//

import UIKit

class ProfilePageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img_ImageCollectionViewParofilePage: UIImageView!

}
